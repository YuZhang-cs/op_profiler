import os

FAIL_LOG_SYMBOL = '[NEW_FAIL]'

def gen_log_list(filename):
    log_list = []
    op_name_list = []
    current_log = ''
    with open(filename,'r') as fin:
        lines = fin.readlines()
        for line in lines:
            if FAIL_LOG_SYMBOL in line:
                if current_log != '':
                    log_list.append(current_log)
                    current_log = line.replace(FAIL_LOG_SYMBOL,'')
                op_name_list.append(line.split(' ')[1])
            else:
                current_log = current_log + line
        log_list.append(current_log)
    return log_list, op_name_list

def check_loc_err(log_str):
    if 'expects to be colocated with' in log_str:
        return True
    else:
        return False

def check_datatype_err(log_str):
    if 'tensorflow.python.framework.errors_impl.InvalidArgumentError' not in log_str:
        return False
    if 'incompatible with expected' in log_str:
        expected_type = log_str.replace('\n','').replace('.','').split(' ')[-1]
        return 'type_err:' + expected_type
    return False

def check_fail_type(log_str):
    if 'expects to be colocated with' in log_str:
        return 'colocation'
    if 'incompatible with expected' in log_str:
        expected_type = log_str.replace('\n','').replace('.','').split(' ')[-1]
        return 'type_err:' + expected_type
    if 'exists but only has 0 outputs' in log_str:
        return 'no_output'
    if 'OOM' in log_str:
        return 'OOM'
    if 'Init operations did not make model ready' in log_str:
        return 'VAR init fail'
    return 'unknown'

def analyze_log_file(filename, output_filename = ''):
    print('Analyzing log file:', filename)
    if output_filename == '':
        output_filename = 'analyze/analyze_'+filename
    log_list, op_name_list = gen_log_list(filename)
    op_fail_type = []
    fail_type_list = []
    fail_type_cnts = {}
    unknown_log_id_list = []
    total_fail_cnt = 0
    for i in range(len(log_list)):
        log = log_list[i]
        fail_type = check_fail_type(log)
        op_fail_type.append(fail_type)
        if fail_type == 'unknown':
            unknown_log_id_list.append(i)
    for i in range(len(op_fail_type)):
        fail_type = op_fail_type[i]
        if fail_type not in fail_type_cnts:
            fail_type_cnts[fail_type] = 1
            fail_type_list.append(fail_type)
        else:
            fail_type_cnts[fail_type] += 1
    with open(output_filename, 'w') as fout:
        for fail_type in fail_type_list:
            fout.write('%s, %d\n' % (fail_type, fail_type_cnts[fail_type]))
            print('%s, %d' % (fail_type, fail_type_cnts[fail_type]))
            total_fail_cnt += fail_type_cnts[fail_type]
        fout.write('Failed op list:\n')
        for i in range(len(op_name_list)):
            fout.write('%s,%s' % (op_name_list[i], op_fail_type[i]))
            if op_fail_type[i] == 'unknown':
                fout.write(',%s\n' % log_list[i])
            else:
                fout.write('\n')
    print('total fail: ', total_fail_cnt)
    return fail_type_cnts

def analyze_overall(filename):
    overall_result = [0, 0, 0, 0]
    with open(filename, 'r') as fdin:
        lines = fdin.readlines()
    for line in lines:
        if len(line.split(',')) != 2:
            continue
        key = line.split(',')[0]
        value = line.split(',')[1]
        if key == 'profile node':
            overall_result[0] = int(value)
        if key == 'fail node':
            overall_result[1] = int(value)
        if key == 'total node':
            overall_result[2] = int(value)
        if key == 'coverage':
            overall_result[3] = float(value) * 100
    return overall_result

if __name__ == '__main__':
    filetree = os.walk('./online_results')
    records_key = []
    records_value = []
    all_fail_types = []
    analyze_results = {}
    overall_results = {}
    for path, dirList, fileList in filetree:
        for fileName in fileList:
            if '.csv' in fileName:
                fileFullName = os.path.join(path,fileName)
                model_name = fileName.replace('log_', '').replace('.txt', '')
                overall_result = analyze_overall(fileFullName)
                overall_results[model_name] = overall_result
            if '.txt' not in fileName:
                continue
            fileFullName = os.path.join(path,fileName)
            fail_type_cnts = analyze_log_file(fileFullName, 
                            'analyze/analyze_'+fileName.replace('.txt','.csv'))
            for fail_type in fail_type_cnts:
                if fail_type not in all_fail_types:
                    all_fail_types.append(fail_type)
            model_name = fileName.replace('log_', '').replace('.txt', '')
            analyze_results[model_name] = fail_type_cnts
    all_fail_types = sorted(all_fail_types)
    with open('mdresult.txt', 'w') as fdout: 
        # Output overall status
        fdout.write('| --- | pass | fail | total | coverage% |\n')
        fdout.write('| --- | --- | --- | --- | --- |\n')
        for model_name in sorted(overall_results):
            overall_result = overall_results[model_name]
            fdout.write('| %s | %d | %d | %d | %.2f |\n' % (
                            model_name,
                            overall_result[0],
                            overall_result[1],
                            overall_result[2],
                            overall_result[3]))

        # Output fail detail
        # Output form head
        fdout.write('| --- |')
        for fail_type in all_fail_types:
            fdout.write(' %s |' % fail_type)
        fdout.write('\n')
        fdout.write('| --- |')
        for i in range(len(all_fail_types)):
            fdout.write(' --- |')
        fdout.write('\n')
        # Output form body
        for model_name in sorted(analyze_results):
            fail_type_cnts = analyze_results[model_name]
            fdout.write('| %s |' % model_name)
            for fail_type in all_fail_types:
                if fail_type in fail_type_cnts:
                    fdout.write(' %d ' % fail_type_cnts[fail_type])
                else:
                    fdout.write(' --- ')
                fdout.write('|')
            fdout.write('\n')

            
        
        
