import sys

#from src import node_define
import modify_test_graph as mod
import online_profiling
import tensorflow as tf
import horovod.tensorflow as hvd
import json
import os

FLAGS = tf.app.flags.FLAGS
'''
tf.app.flags.DEFINE_string('model_name', 
                        'alexnet',
                        """The name of model, used to generate output filename """)
tf.app.flags.DEFINE_string('model_path', 
                        'test_graphs/baseline_graphs/alexnet_bsDefault_gpunum1_partitionGraph_0.pbtxt',
                        """The dir of pbtxt graph file """)
tf.app.flags.DEFINE_string('result_dir', 
                        'baseline_graphs_result/alexnet/',
                        """The detail result dir """)
tf.app.flags.DEFINE_string('overall_output', 
                        'baseline_result/graphs_overall.txt',
                        """The output file """)
'''

def test_model(model_path='test_graphs/GraphSharing/',
                result_dir = 'graph_sharing_result/'):
    all_result = []
    if not os.path.exists(result_dir):
        os.makedirs(result_dir)
    print('[DEBUG] Check file: ', model_path)
    if '.pbtxt' not in model_path:
        print('[ERROR] Given file is not a .pbtxt file')
    print('[DEBUG] open file: ', model_path)
    graph_def = mod.load_protobuf_from_file(model_path)
    model_name = FLAGS.model_name
    result_filename = result_dir + '/profiling.csv'
    log_filename = result_dir + 'log_' + model_name + '.txt'
    step_result_path = FLAGS.step_result_path + '/' + model_name + '/'
    if not os.path.exists(step_result_path):
        os.makedirs(step_result_path)
    result = online_profiling.graph_profiling(graph_def,
                    result_filename = result_filename,
                    step_result_path = step_result_path,
                    fail_log_filename = log_filename)
    all_result.append((model_name, result))
    return all_result

if __name__ == '__main__':
    output_file = FLAGS.overall_output
    model_path = FLAGS.model_path
    result_dir = FLAGS.result_dir
    all_result = test_model(model_path = model_path,
                    result_dir = result_dir)
    with open(output_file, 'a') as fd_out:
        fd_out.write('| --- | pass | fail | total | coverage% |\n')
        fd_out.write('| --- | --- | --- | --- | --- |\n')
        for i in range(len(all_result)):
            model_name, result = all_result[i]
            fd_out.write('| %s | %d | %d | %d | %.2f |\n' % (
                model_name,
                result[0],
                result[1],
                result[2],
                result[3])
                )

