from google.protobuf import text_format
import tensorflow as tf

def load_protobuf_from_file(filename):
    with open(filename, 'r') as fdin:
        file_content = fdin.read()
        try:
            graph_def = text_format.Parse(file_content, tf.GraphDef())
            return graph_def
        except text_format.ParseError as e:
            raise IOError("Cannot parse file %s: %s." 
                            % (filename, str(e)))
    return graph_def

if __name__ == '__main__':
    graph_def = load_protobuf_from_file('basic_graphs/conv2d_bp_input.pbtxt')
    print("Loaded")
    #modify_data_shape(graph_def, 'data_0/shape', [1024,1024])
    #modify_data_shape(graph_def, 'data_1/shape', [1024,512])
    config=tf.ConfigProto()
    tf.reset_default_graph()
    tf.import_graph_def(graph_def)
    with tf.train.MonitoredTrainingSession(
            config=config) as sess:
        sess.graph.as_default()
        final_tensor = sess.graph.get_tensor_by_name('import/test_bp_op:0')
        print('run')
        print(sess.run(final_tensor))
