from google.protobuf import text_format
import tensorflow as tf
from tensorflow.python.platform import gfile
import time
import math
import modify_test_graph as mod
import generate_basic_graph as gen
from random import choice
import traceback
import online_prof_define
import json

import os

global_step_time_list = []
global_op_time_list = []
FLAGS = tf.app.flags.FLAGS

GPU_JOB_STREAM_NAME = '/job:localhost/replica:0/task:0/device:GPU:0 Compute'
GPU_STREAM_NAME = '/device:GPU:0/stream:all Compute'
CPU_STREAM_NAME = '/job:localhost/replica:0/task:0/device:CPU:0 Compute'
STREAM_CREATE_NAME = 'process_name'

class _LoggerHook(tf.train.SessionRunHook):
    """Logs end-to-end time use"""
    def begin(self):
        global global_step_time_list
        self._step = -1
        self._step_time_list = global_step_time_list

    def before_run(self, run_context):
        self._step += 1
        self._start_time = time.time()
        
    def after_run(self, run_context, run_values):
        global log_file
        self._end_time = time.time()

        duration = self._end_time - self._start_time
        print('Step %d: %.6f sec' % (self._step, duration))
        self._step_time_list.append(duration)

# Parse one step timeline
# tl_record: [CPU_OP_time, GPU_OP_CPU_time, GPU_OP_GPU_time]
def parse_single_prof_timeline(filename):
    global GPU_JOB_STREAM_NAME
    global GPU_STREAM_NAME
    global CPU_STREAM_NAME
    global STREAM_CREATE_NAME

    # The pid of 3 different streams
    gpu_pid = -1
    cpu_pid = -1
    gpu_job_pid = -1
    # Load the data, find pid of different streams
    with open(filename,'r') as fd:
        trace_list = json.load(fd)['traceEvents']
    for event in trace_list:
        if gpu_pid >= 0 and cpu_pid >= 0:
            break
        if event['name'] != STREAM_CREATE_NAME:
            continue 
        if event['args']['name'] == CPU_STREAM_NAME:
            cpu_pid = event['pid']
        if event['args']['name'] == GPU_STREAM_NAME:
            gpu_pid = event['pid']
        if event['args']['name'] == GPU_JOB_STREAM_NAME:
            gpu_job_pid = event['pid']

    # Record for each test op.
    # Each record contains [cpu_time, gpu_job_time, gpu stream time]
    start_time_list = []
    end_time_list = []
    record_list = []
    for event in trace_list:
        if event['name'] == 'unknown':
            continue
        if 'args' not in event:
            continue
        if 'name' not in event['args']:
            continue
        if 'test_op' not in event['args']['name']:
            continue
        if 'test_op_' not in event['args']['name']:
            op_id = 0
        else:
            op_id = int(event['args']['name'].replace('test_op_',''))
        while(op_id + 1 > len(record_list)):
            record_list.append([-1,-1,-1])
            start_time_list.append([-1,-1,-1])
            end_time_list.append([-1,-1,-1])
        
        if event['pid'] == cpu_pid:
            stream_id = 0
        elif event['pid'] == gpu_job_pid:
            stream_id = 1
        elif event['pid'] == gpu_pid:
            stream_id = 2
        else:
            continue
        
        # Record start time
        if start_time_list[op_id][stream_id] == -1:
            start_time_list[op_id][stream_id] = event['ts']
        # Record end time
        if end_time_list[op_id][stream_id] < event['ts'] + event['dur']:
            end_time_list[op_id][stream_id] = event['ts'] + event['dur']
    # Calculate the time use
    avg_record = [0,0,0]
    for i in range(len(record_list)):
        for stream_id in [0,1,2]:
            record_list[i][stream_id] = end_time_list[i][stream_id] - \
                                        start_time_list[i][stream_id]
            avg_record[stream_id] += record_list[i][stream_id]
    
    for stream_id in [0,1,2]:
        avg_record[stream_id] /= len(record_list)
    
    return avg_record

# Parse all steps timeline of an op
def parse_all_timeline(timeline_dir, warmup_steps):
    filetree = os.walk(timeline_dir)
    avg_record = [0,0,0]
    record_cnt = 0
    for path, dirList, fileList in filetree:
        for fileName in fileList:
            fileFullName = os.path.join(path,fileName)
            print('[DEBUG] Check file: ', fileFullName)
            if fileFullName[-4:] != 'json':
                continue
            step_id = int(fileName.replace('timeline-','').replace('.json',''))
            if step_id < warmup_steps:
                continue
            print('[DEBUG] open file: ', fileFullName)
            timeline_record = parse_single_prof_timeline(fileFullName)
            for i in [0,1,2]:
                avg_record[i] += timeline_record[i]
            record_cnt += 1
    for i in [0,1,2]:
        avg_record[i] /= record_cnt
    return avg_record

def get_medium(input_list):
    sorted_list = sorted(input_list)
    list_len = len(sorted_list)
    return sorted_list[list_len // 2]

def get_min(input_list):
    sorted_list = sorted(input_list)
    return sorted_list[0]

'''
Ideal step time range: ideal_step_sec * (1 +- step_time_range_ratio)
Return: Average op time & std_err.
Average op time: Average time of each test op.
If avg op time is out of step time range, std_err is set to -1
'''
def profiling(graph_def=None, warmingup_round=5, test_round=10, 
                final_tensor_name='', output_filename='tmp.txt',
                test_op_chain_len=1000, auto_tune=False,
                ideal_step_sec=0.5, step_time_range_ratio=0.5,
                step_result_filename=None,
                enable_timeline=False,
                timeline_path='./profiling_timeline/',
                use_timeline_prof=False):
    global global_step_time_list
    global global_op_time_list
    global_step_time_list = []
    global_op_time_list = []
    
    config=tf.ConfigProto(allow_soft_placement=True, log_device_placement=False)
    tf.config.optimizer.set_experimental_options(
        {
            'disable_model_pruning': True,
            'dependency_optimization': False,
            'disable_meta_optimizer': True
        }
    )
    if graph_def != None:
        tf.reset_default_graph()
        tf.import_graph_def(graph_def, name='')

    hooks = [_LoggerHook()]
    if FLAGS.save_profiling_graph == 1:
        options = tf.RunOptions(output_partition_graphs=True)
        run_metadata = tf.RunMetadata()
    if enable_timeline:
        global_step = tf.train.get_or_create_global_step()
        timeline_hook = tf.train.ProfilerHook(save_steps=2,\
                        output_dir = timeline_path)
        hooks.append(timeline_hook)
        increase_step_op = tf.assign_add(global_step, 1, name='inc_step')
        final_tensor_name.append('inc_step')
    with tf.train.MonitoredTrainingSession(
            config=config, hooks=hooks) as sess:
        for i in range(test_round):
            if FLAGS.save_profiling_graph == 1:
                sess.run(final_tensor_name,options = options, run_metadata = run_metadata)
            else:
                sess.run(final_tensor_name)
            step_time = global_step_time_list[-1]
            op_time = step_time / test_op_chain_len
            # Trans into micro second
            op_time *= 1000000.0
            global_op_time_list.append(op_time)
            if i >= warmingup_round:
                step_time = global_step_time_list[-1]
                if not auto_tune:
                    continue
                #if  step_time > ideal_step_sec * (1+step_time_range_ratio) or \
                #    step_time < ideal_step_sec * (1-step_time_range_ratio):
                if  step_time > ideal_step_sec * (1+step_time_range_ratio):
                    print('[DEBUG]Triggered auto tune!')
                    return op_time, -1
        # Log profiling graph if needed
        if FLAGS.save_profiling_graph == 1:
            print('Ready to dump partition graph')
            for i, partition_graph_def in enumerate(run_metadata.partition_graphs):
                meta_graph_path = FLAGS.profiling_graph_path
                if not os.path.exists(meta_graph_path):
                    os.makedirs(meta_graph_path)
                with open('%s/%d.pbtxt' % (meta_graph_path,i), 'w') as f:
                    print(partition_graph_def, file=f)
    if enable_timeline:
        avg_tl_record = parse_all_timeline(timeline_path, warmingup_round)
        if avg_tl_record[0] > 0:
            tl_timeuse = avg_tl_record[0]
        else:
            tl_timeuse = max(avg_tl_record[1], avg_tl_record[2])
    avg_op_time = 0.0
    mse = 0.0
    #medium_op_time = get_medium(global_op_time_list[warmingup_round:test_round])
    min_op_time = get_min(global_op_time_list[warmingup_round:test_round])
    legal_op_time_list = []
    '''
    legal_op_max = min_op_time * (1+FLAGS.outlier_filter_medium_range)
    legal_op_min = min_op_time * (1-FLAGS.outlier_filter_medium_range)
    '''
    # legal step time should be in min_step_time + 10ms
    legal_op_min = min_op_time - 1 # min - 1us, prevent precise problem
    legal_op_max = min_op_time + (10000.0 / test_op_chain_len) # mim step time + 10ms
    print('[DEBUG] hard_legal_op_max = %f' % legal_op_max)
    ranged_legal_op_max = min_op_time * (1+FLAGS.outlier_filter_medium_range) # percent range limit
    if ranged_legal_op_max < legal_op_max:
        legal_op_max = ranged_legal_op_max
    print('[DEBUG] ranged_legal_op_max = %f' % ranged_legal_op_max)
    legal_op_cnt = 0
    with open(output_filename, 'w') as fdout:
        for i in range(warmingup_round, test_round):
            if FLAGS.outlier_filter_medium:
                if  global_op_time_list[i] > legal_op_max or \
                    global_op_time_list[i] < legal_op_min:
                    continue
            legal_op_cnt += 1
            avg_op_time += global_op_time_list[i]
            legal_op_time_list.append(global_op_time_list[i])
            fdout.write(str(global_op_time_list[i])+'\n')
        avg_op_time /= legal_op_cnt
        print('op_chain_len: %d' % test_op_chain_len)
        print('Avg op time(usec): %.6f' % avg_op_time)
        for i in range(warmingup_round, test_round):
            if FLAGS.outlier_filter_medium:
                if  global_op_time_list[i] > legal_op_max or \
                    global_op_time_list[i] < legal_op_min:
                    continue
            mse += (global_op_time_list[i] -  avg_op_time) ** 2
        mse /= legal_op_cnt
        mean_std_err = math.sqrt(mse)
        print('Mean square error: %.6f'% mse)
        print('Mid: %.6f'% get_medium(legal_op_time_list))
        print('Mean standard error: %.6f'% mean_std_err)
        if enable_timeline:
            print('Timeline avg(usec): %.6f', avg_tl_record)
            fdout.write('timeline_avg, %f\n' % tl_timeuse)
    
    
    if step_result_filename != None:
        with open(step_result_filename, 'w') as fdout:
            for i in range(len(global_step_time_list)):
                fdout.write(str(global_step_time_list[i])+'\n')
            fdout.write('chain_len, %d\n' % test_op_chain_len)
            fdout.write('warmup_step, %d\n' % warmingup_round)
            fdout.write('total_step, %d\n' % test_round)
            
    
    if use_timeline_prof:
        return avg_tl_record, 0
    else:
        return avg_op_time, mean_std_err

def single_profiling_test(  origin_graph_filename,
                            modify_shape_list,
                            test_op,
                            test_op_chain_length,
                            warmup_steps=5,
                            test_steps=20,
                            result_filename='profiling_result.txt',
                            enable_timeline=False,
                            timeline_path='./profiling_timeline/'
                            ):
    graph_def = mod.load_protobuf_from_file(origin_graph_filename)
    print("Loaded")
    for modify in modify_shape_list:
        #mod.modify_data_shape(graph_def, 'data_0/shape', [1024,1024])
        mod.modify_data_shape(graph_def, modify[0], modify[1])
 
    print('Data shape modified')
    final_tensors = mod.modify_test_graph(graph_def, test_op, 
                                test_op_chain_length)
    print('OP chain generated')
    #mod.save_protobuf_to_file(graph_def, 'test_graph.pbtxt')

    avg_tl_record = profiling(graph_def, warmup_steps, test_steps, 
        test_op_chain_len=test_op_chain_length,
        output_filename=result_filename,
        final_tensor_name=final_tensors,
        enable_timeline=enable_timeline,
        timeline_path=timeline_path)
    return avg_tl_record






