import tensorflow as tf
from google.protobuf import text_format
def load_protobuf_from_file(filename, proto=tf.GraphDef()):
    with open(filename, 'r') as fdin:
        file_content = fdin.read()
        try:
            graph_def = text_format.Parse(file_content, tf.GraphDef())
            return graph_def
        except text_format.ParseError as e:
            raise IOError("Cannot parse file %s: %s." 
                            % (filename, str(e)))
    return graph_def

def save_protobuf_to_file(protobuf, filename='test_graph.pbtxt'):
    with open(filename, 'w') as fdout:
        fdout.write(text_format.MessageToString(protobuf))

def get_node_by_name(graph_def, node_name):
    for node in graph_def.node:
        if node.name == node_name:
            return node
    return None

graph_filename = './test_graphs/jf_graphs/bert_base/run_graph.pbtxt'

graph_def = load_protobuf_from_file(graph_filename)

recv_source_node_dict = {}

# Find all recv nodes, record their source node in the dict
for node in graph_def.node:
    if 'Recv' not in node.op:
        continue
    if len(node.input)!= 1:
        print('[ERROR] Recv op has multi input! %s' % node.name)
    send_node_name = node.input[0].replace('^','')
    send_node = get_node_by_name(graph_def, send_node_name)
    if len(send_node.input)!= 1:
        print('[ERROR] Send op has multi input! %s' % send_node.name)
    source_node_name = send_node.input[0]

    recv_source_node_dict[node.name] = source_node_name

# Modify the input node name.
for node in graph_def.node:
    for i in range(len(node.input)):
        input_name = node.input[i]
        if input_name in recv_source_node_dict:
            source_name = recv_source_node_dict[input_name]
            node.input[i] = source_name


    '''
    # Change recv node to NoOp, change name to dummy name
    node.op = 'NoOp'
    raw_recv_op_name = node.name
    node.name = 'Dummy_%s' % node.name
    # Change send node to NoOp, and redirect input as dependent input to recv node
    send_node.input[0] = '^' + node.name
    # Change source node's name to recv node's name
    source_node.name = raw_recv_op_name
    '''
save_protobuf_to_file(graph_def, graph_filename)
print('Done!')
