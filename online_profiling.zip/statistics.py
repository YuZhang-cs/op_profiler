import os
import math
import csv
import random

'''
Read all profiling data in record_path.
Save them in two list, record_key, record_value.
record_key: First element is op, other op are input parameters.
record_value: [average_time, mean_square_error, mean_standard_error]
'''
def read_dir(record_path):
    filetree = os.walk(record_path)
    records = []
    #records_key = []
    #records_value = []
    cnt = 0
    for path, dirList, fileList in filetree:
        for fileName in fileList:
            record = fileName.replace('.csv','').split('_')
            fileFullName = os.path.join(path,fileName)
            with open(fileFullName) as fdin:
                avg_time = 0.0
                line_cnt = 0
                lines = fdin.readlines()
                for line in lines:
                    time = float(line.replace('\n', ''))
                    avg_time += time
                    line_cnt += 1
                avg_time /= line_cnt
                #if avg_time > 40.0:
                #    cnt += 1
                mean_square_err = 0.0
                for line in lines:
                    time = float(line.replace('\n', ''))
                    mean_square_err += (time - avg_time) ** 2
                mean_square_err /= line_cnt
                mean_std_err = math.sqrt(mean_square_err) 
            record.extend([avg_time,mean_square_err,mean_std_err])
            records.append(record)
            #records_key.append(record_key)
            #records_value.append([avg_time, mean_square_err, mean_std_err])
    #print(cnt)
    '''
    with open('single_profiling_records.txt','w') as fdout:
        for i in range(len(records_key)):
            record_str = ''
            for key in records_key[i]:
                record_str = record_str + key + ' '
            for value in records_value[i]:
                record_str = record_str + str(value) + ' '
            record_str = record_str + '\n'
            fdout.write(record_str)
    '''
    #return records_key, records_value
    return records

#generate csv files for each op
def generate_csv(folderpath):
    records_small = read_dir(folderpath+'/small/')
    records_normal = read_dir(folderpath+'/normal/')
    records_large = read_dir(folderpath+'/large/')
    #records_real = read_dir(folderpath+'/real/')
    records = []
    h = {}
    h['Conv2D'] = ['Name', 'n', 'h', 'w', 'c', 'f_x', 'f_y', 'f_c', 'stride[1]', 'stride[2]', 'dilation[1]', 'avg time (us)', 'variance', 'std deviation', 'std deviation / avg time']
    h['binary'] = ['Name', 'n', 'm', 'avg time (us)', 'variance', 'std deviation', 'std deviation / avg time']
    h['Relu'] = ['Name', 'n', 'h', 'w', 'c', 'avg time (us)', 'variance', 'std deviation', 'std deviation / avg time']
    h['MatMul'] = ['Name', 'n', 'k', 'm','avg time (us)', 'variance','std deviation', 'std devitaion / avg time'] 
    h['MaxPool'] = ['Name', 'n','h','w','c','ksize[1]','ksize[2]','stride[1]','stride[2]','avg time (us)','variance','std deviation','std deviation / avg time']
    iD = ''
    wt = {}
    wt['Add'] = csv.writer(open(folderpath+'/Add.csv', 'w'), delimiter = ',')
    wt['Sub'] = csv.writer(open(folderpath+'/Sub.csv', 'w'), delimiter = ',')
    wt['Mul'] = csv.writer(open(folderpath+'/Mul.csv', 'w'), delimiter = ',')
    wt['RealDiv'] = csv.writer(open(folderpath+'/RealDiv.csv', 'w'), delimiter = ',')
    wt['Conv2D'] = csv.writer(open(folderpath+'/Conv2D.csv', 'w'), delimiter = ',')
    wt['Conv2DBackpropInput'] = csv.writer(open(folderpath+'/Conv2DBackpropInput.csv', 'w'), delimiter = ',')
    wt['Conv2DBackpropFilter'] = csv.writer(open(folderpath+'/Conv2DBackpropFilter.csv', 'w'), delimiter = ',')
    wt['Relu'] = csv.writer(open(folderpath+'/Relu.csv', 'w'), delimiter = ',')
    wt['MatMul'] = csv.writer(open(folderpath+'/MatMul.csv', 'w'), delimiter = ',')
    wt['MaxPool'] = csv.writer(open(folderpath+'/MaxPool.csv', 'w'), delimiter = ',')
    wt['Add'].writerow(h['binary'])
    wt['Sub'].writerow(h['binary'])
    wt['Mul'].writerow(h['binary'])
    wt['RealDiv'].writerow(h['binary'])
    wt['Relu'].writerow(h['Relu'])
    wt['Conv2D'].writerow(h['Conv2D'])
    wt['Conv2DBackpropInput'].writerow(h['Conv2D'])
    wt['Conv2DBackpropFilter'].writerow(h['Conv2D'])
    wt['MatMul'].writerow(h['MatMul'])
    wt['MaxPool'].writerow(h['MaxPool'])
    
    #status = {}
    #status['Add'] = 0
    #status['Sub'] = 0
    #status['Mul'] = 0
    #status['RealDiv'] = 0
    #status['MatMul'] = 0
    
    cnt = 0
    for r in records_small:
        percentage = round(100 * float(r[-1])/float(r[-3]), 2)
        r.append(str(percentage) + '%')
        if percentage >= 2.5:
            cnt += 1
            continue
        #if float(r[-4]) > 40.0:
            #cnt += 1
            #continue
        records.append(r)
        #if status[r[0]] < 2000:
        #    wt[r[0]].writerow(r)
        #    status[r[0]] += 1
    print("There are " + str(cnt) + " records invalid in small inputs.(error > 2.5\%)")
    print("small total: %d" % len(records_small))

    records_normal.extend(records_large)
    cnt = 0
    for r in records_normal:
        percentage = round(100 * float(r[-1])/float(r[-3]), 2)
        r.append(str(percentage) + '%')
        if percentage >= 2.5:
            cnt += 1
            continue
        records.append(r)
    print("There are "+ str(cnt) + " records invalid in normal and large inputs.(error > 2.5%)")
    print("normal total: %d" % len(records_normal))
    '''
    real_cnt = 0
    for r in records_real:
        real_cnt += 1
        if real_cnt >= 4000:
            break
        percentage = round(100 * float(r[-1])/float(r[-3]), 2)
        r.append(str(percentage) + '%')
        if percentage >= 2:
            cnt += 1
            continue
        #if float(r[-4]) > 40.0:
            #cnt += 1
            #continue
        records.append(r)
        #if status[r[0]] < 2000:
        #    wt[r[0]].writerow(r)
        #    status[r[0]] += 1
    print("There are " + str(cnt) + " records invalid in real inputs.(error > 2\%)")
    print("Real total: %d" % len(records_real))
    '''

    print("Total: %d" % len(records))
    random.shuffle(records)
    for r in records:
        wt[r[0]].writerow(r)
    
    

'''
'''
def analyze_record(records_key, records_value,
                    analyze_key_id_list, standard_key_value_list):
    return

if __name__ == '__main__':
    generate_csv('op_prof_nchw_result')
