**Coverage of online profiling module**

| --- | pass | fail | total | coverage% |
| --- | --- | --- | --- | --- |
| SimpleCNN_profiling.csv | 118 | 12 | 130 | 90.77 |
| acoustic_model_imagenet_profiling.csv | 121 | 14 | 135 | 89.63 |
| alexnet_cifar10_profiling.csv | 126 | 12 | 138 | 91.30 |
| alexnet_imagenet_profiling.csv | 196 | 18 | 214 | 91.59 |
| alexnet_owt_imagenet_profiling.csv | 192 | 18 | 210 | 91.43 |
| deep_mnist_imagenet_profiling.csv | 138 | 16 | 154 | 89.61 |
| densenet100_k12_cifar10_profiling.csv | 4386 | 694 | 5080 | 86.34 |
| densenet100_k24_cifar10_profiling.csv | 4386 | 694 | 5080 | 86.34 |
| densenet40_k12_cifar10_profiling.csv | 1746 | 274 | 2020 | 86.44 |
| googlenet_imagenet_profiling.csv | 1449 | 163 | 1612 | 89.89 |
| inception3_imagenet_profiling.csv | 2213 | 249 | 2462 | 89.89 |
| inception4_imagenet_profiling.csv | 3498 | 401 | 3899 | 89.72 |
| lenet_imagenet_profiling.csv | 105 | 10 | 115 | 91.30 |
| nasnet_cifar10_profiling.csv | 17949 | 2229 | 20178 | 88.95 |
| nasnet_imagenet_profiling.csv | 8428 | 882 | 9310 | 90.53 |
| nasnetlarge_imagenet_profiling.csv | 19779 | 2461 | 22240 | 88.93 |
| overfeat_imagenet_profiling.csv | 192 | 18 | 210 | 91.43 |
| resnet101_imagenet_profiling.csv | 2860 | 415 | 3275 | 87.33 |
| resnet101_v2_imagenet_profiling.csv | 2501 | 282 | 2783 | 89.87 |
| resnet110_cifar10_profiling.csv | 2847 | 343 | 3190 | 89.25 |
| resnet110_v2_cifar10_profiling.csv | 2753 | 290 | 3043 | 90.47 |
| resnet152_imagenet_profiling.csv | 4254 | 619 | 4873 | 87.30 |
| resnet152_v2_imagenet_profiling.csv | 3725 | 418 | 4143 | 89.91 |
| resnet18_imagenet_profiling.csv | 690 | 115 | 805 | 85.71 |
| resnet200_imagenet_profiling.csv | 5566 | 811 | 6377 | 87.28 |
| resnet20_cifar10_profiling.csv | 552 | 73 | 625 | 88.32 |
| resnet20_v2_cifar10_profiling.csv | 548 | 65 | 613 | 89.40 |
| resnet269_imagenet_profiling.csv | 7452 | 1087 | 8539 | 87.27 |
| resnet32_cifar10_profiling.csv | 842 | 95 | 937 | 89.86 |
| resnet32_v2_cifar10_profiling.csv | 842 | 95 | 937 | 89.86 |
| resnet34_imagenet_profiling.csv | 1226 | 211 | 1437 | 85.32 |
| resnet44_cifar10_profiling.csv | 1164 | 145 | 1309 | 88.92 |
| resnet44_v2_cifar10_profiling.csv | 1136 | 125 | 1261 | 90.09 |
| resnet50_imagenet_profiling.csv | 1466 | 211 | 1677 | 87.42 |
| resnet50_v2_imagenet_profiling.csv | 1277 | 146 | 1423 | 89.74 |
| resnet56_cifar10_profiling.csv | 1470 | 181 | 1651 | 89.04 |
| resnet56_v2_cifar10_profiling.csv | 1430 | 155 | 1585 | 90.22 |
| resnet_152_profiling.csv | 7672 | 324 | 7996 | 95.95 |
| resnet_50_profiling.csv | 2690 | 120 | 2810 | 95.73 |
| sensor_net_imagenet_profiling.csv | 87 | 10 | 97 | 89.69 |
| trivial_cifar10_profiling.csv | 72 | 8 | 80 | 90.00 |
| trivial_imagenet_profiling.csv | 72 | 8 | 80 | 90.00 |
| validation_profiling.csv | 212 | 12 | 224 | 94.64 |
| vgg11_imagenet_profiling.csv | 262 | 24 | 286 | 91.61 |
| vgg13_imagenet_profiling.csv | 306 | 28 | 334 | 91.62 |
| vgg16_imagenet_profiling.csv | 372 | 34 | 406 | 91.63 |
| vgg19_imagenet_profiling.csv | 438 | 40 | 478 | 91.63 |
| vgg_19_profiling.csv | 1118 | 48 | 1166 | 95.88 |

**Fail node type in different module**

| --- | type_err:float_ref | type_err:int32 | type_err:int64 | type_err:int64_ref | unknown |
| --- | --- | --- | --- | --- | --- |
| SimpleCNN | 10 | --- | 1 | --- | 1 |
| acoustic_model_imagenet | 12 | --- | 1 | --- | 1 |
| alexnet_cifar10 | 20 | --- | 2 | --- | 2 |
| alexnet_imagenet | 16 | --- | 1 | --- | 1 |
| alexnet_owt_imagenet | 16 | --- | 1 | --- | 1 |
| deep_mnist_imagenet | 14 | --- | 1 | --- | 1 |
| densenet100_k12_cifar10 | 398 | 294 | 1 | --- | 1 |
| densenet100_k24_cifar10 | 398 | 294 | 1 | --- | 1 |
| densenet40_k12_cifar10 | 158 | 114 | 1 | --- | 1 |
| googlenet_imagenet | 116 | 45 | 1 | --- | 1 |
| inception3_imagenet | 190 | 57 | 1 | --- | 1 |
| inception4_imagenet | 300 | 99 | 1 | --- | 1 |
| lenet_imagenet | 8 | --- | 1 | --- | 1 |
| nasnet_cifar10 | 938 | 478 | 164 | --- | 649 |
| nasnet_imagenet | 746 | 134 | 1 | --- | 1 |
| nasnetlarge_imagenet | 1022 | 536 | 182 | --- | 721 |
| overfeat_imagenet | 16 | --- | 1 | --- | 1 |
| resnet101_imagenet | 314 | 99 | 1 | --- | 1 |
| resnet101_v2_imagenet | 274 | 6 | 1 | --- | 1 |
| resnet110_cifar10 | 329 | 12 | 1 | --- | 1 |
| resnet110_v2_cifar10 | 276 | 12 | 1 | --- | 1 |
| resnet152_imagenet | 467 | 150 | 1 | --- | 1 |
| resnet152_v2_imagenet | 410 | 6 | 1 | --- | 1 |
| resnet18_imagenet | 65 | 48 | 1 | --- | 1 |
| resnet200_imagenet | 611 | 198 | 1 | --- | 1 |
| resnet20_cifar10 | 59 | 12 | 1 | --- | 1 |
| resnet20_v2_cifar10 | 51 | 12 | 1 | --- | 1 |
| resnet269_imagenet | 818 | 267 | 1 | --- | 1 |
| resnet32_cifar10 | 81 | 12 | 1 | --- | 1 |
| resnet32_v2_cifar10 | 81 | 12 | 1 | --- | 1 |
| resnet34_imagenet | 113 | 96 | 1 | --- | 1 |
| resnet44_cifar10 | 131 | 12 | 1 | --- | 1 |
| resnet44_v2_cifar10 | 111 | 12 | 1 | --- | 1 |
| resnet50_imagenet | 161 | 48 | 1 | --- | 1 |
| resnet50_v2_imagenet | 138 | 6 | 1 | --- | 1 |
| resnet56_cifar10 | 167 | 12 | 1 | --- | 1 |
| resnet56_v2_cifar10 | 141 | 12 | 1 | --- | 1 |
| resnet_152 | 314 | 6 | 3 | 1 | --- |
| resnet_50 | 110 | 6 | 3 | 1 | --- |
| sensor_net_imagenet | 8 | --- | 1 | --- | 1 |
| trivial_cifar10 | 6 | --- | 1 | --- | 1 |
| trivial_imagenet | 6 | --- | 1 | --- | 1 |
| validation | 8 | --- | 3 | 1 | --- |
| vgg11_imagenet | 22 | --- | 1 | --- | 1 |
| vgg13_imagenet | 26 | --- | 1 | --- | 1 |
| vgg16_imagenet | 32 | --- | 1 | --- | 1 |
| vgg19_imagenet | 38 | --- | 1 | --- | 1 |
| vgg_19 | 40 | --- | 3 | 1 | 4 |


**Fail type description and solution**
***type_err***
The default test graph uses float as data type, if the data type of op in model is not float, this will end up with type err. I will add more data type supporting to the profiling module.
However, there are also some other reason that will cause type err.

type_err:int: Op takes integer as input sometime will use the input value to do special task. For example, input is the shape of a value, and the op will create a tensor with given shape. 

type_err:ref: These ops takes a reference of tensor as input, usually act as assignment ops. We need to prepare corresponding Variable op in test graph. However, due to TensorFlow BUG, we cannot directly use .pbtxt to build graph in MonitoredSession. I will discuss with them about this issue.



