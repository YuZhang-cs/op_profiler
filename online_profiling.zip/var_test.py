from google.protobuf import text_format
import tensorflow as tf
from tensorflow.python.platform import gfile
import time
import math
import modify_test_graph as mod

global_step_time_list = []

class _LoggerHook(tf.train.SessionRunHook):
    """Logs end-to-end time use"""
    def begin(self):
        global global_step_time_list
        self._step = -1
        self._step_time_list = global_step_time_list

    def before_run(self, run_context):
        self._step += 1
        self._start_time = time.time()
        
    def after_run(self, run_context, run_values):
        global log_file
        self._end_time = time.time()

        duration = self._end_time - self._start_time
        print('Step %d: %.6f sec' % (self._step, duration))
        self._step_time_list.append(duration)

def gen_var(name = 'test_var'):
    var = tf.Variable([1,2,3], dtype=tf.int64, name = 'test_var')
    var2 = tf.Variable([1,2,3], dtype=tf.int64, name = 'test_var2')
    var3 = tf.Variable([1,2,3], dtype=tf.int64, name = 'test_var3')
    return ['test_var', 'test_var2', 'test_var3']

def profiling(graph_def, warmingup_round, test_round, 
                final_tensor_name, output_filename):
    global global_step_time_list
    global_step_time_list = []
    config=tf.ConfigProto()
    #tf.reset_default_graph()
    global_step = tf.train.get_or_create_global_step()

    targets = gen_var()
    profile_hook = tf.train.ProfilerHook(save_steps=1, output_dir='./timeline')
    with tf.train.MonitoredTrainingSession(
            config=config, 
            hooks = [_LoggerHook(), profile_hook]) as sess:
        sess.graph.as_default()
        final_tensor = sess.graph.get_tensor_by_name(final_tensor_name)

        for i in range(test_round):
            sess.run(targets)
    avg_step_time = 0
    mse = 0.0
    with open(output_filename, 'w') as fdout:
        for i in range(warmingup_round, test_round):
            avg_step_time += global_step_time_list[i]
            fdout.write(str(global_step_time_list[i])+'\n')
        avg_step_time /= test_round - warmingup_round
        print('Avg step time: %.6f' % avg_step_time)
        for i in range(warmingup_round, test_round):
            mse += (global_step_time_list[i] -  avg_step_time) ** 2
        mse /= test_round - warmingup_round
        mean_std_err = math.sqrt(mse)
        print('Mean square error: %.6f', mse)
        print('Mean standard error: %.6f', mean_std_err)
    return avg_step_time, mean_std_err

if __name__ == '__main__':
    graph_def = mod.load_protobuf_from_file('basic_graphs/var_test.pbtxt')
    profiling(graph_def, 1, 5, 'test_var:0', 'tmp.txt')