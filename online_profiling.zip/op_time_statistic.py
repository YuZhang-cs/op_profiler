import modify_test_graph as mod
import os
choose_op_list = ['Add', 'Sub', 'Mul', 'Realdiv', 'Relu', 'MaxPool', 
        'MatMul', 'Conv2D', 'Conv2DBackpropInput', 'Conv2DBackpropFilter']

model_list = ['resnet50', 'alexnet','vgg16','inception3','seq2seq','deepspeech','lstm','nasnet']

def load_profiling_result(filename):
    profiling_result = {}
    with open(filename,'r') as fd_in:
        lines = fd_in.readlines()
        for line in lines:
            line_list = line.replace('\n','').split(',')
            if len(line_list)!=3:
                continue
            node_name = line_list[0]
            time = float(line_list[1])
            profiling_result[node_name]=time
    return profiling_result

def sort_op_time(all_op_time):
    op_list = []
    time_list = []
    for op in all_op_time:
        op_list.append(op)
        time_list.append(all_op_time[op])
    for i in range(len(op_list)):
        for j in range(i+1, len(op_list)):
            if time_list[i] < time_list[j]:
                k = time_list[i]
                time_list[i] = time_list[j]
                time_list[j] = k
                k = op_list[i]
                op_list[i] = op_list[j]
                op_list[j] = k
    return op_list, time_list

if not os.path.exists('model_op_statistics'):
    os.makedirs('model_op_statistics/')

for model in model_list:
    fd_out = open('model_op_statistics/%s.txt'%model,'w')
    print('==========')
    print(model)
    print('==========')
    pbtxt_filename = './jf_graphs_result/'+model+'.pbtxt'
    profiling_filename = './jf_graphs_result/'+model+'_profiling.csv'
    
    graph_def = mod.load_protobuf_from_file(pbtxt_filename)
    profiling_result = load_profiling_result(profiling_filename)
    real_node_time_statistic = {}

    total_node_cnt = 0
    choose_op_cnt = 0
    total_time = 0.0
    choose_op_time = 0.0
    not_found_cnt = 0
    all_op_time = {}
    for node in graph_def.node:
        if node.name not in profiling_result:
            print('[ERROR] node %s not in csv! ' % node.name)
            not_found_cnt+=1
            continue
        node_time = profiling_result[node.name]
        if node.op in choose_op_list:
            choose_op_time += node_time
            choose_op_cnt += 1
        if node.op not in all_op_time:
            all_op_time[node.op] = node_time
        else:
            all_op_time[node.op] += node_time
        total_time += node_time
        total_node_cnt += 1
    
    op_list, time_list = sort_op_time(all_op_time)
    time_sum = 0.0
    found_95_flag = False
    found_90_flag = False
    for i in range(len(op_list)):
        time_sum += time_list[i]
        print(op_list[i],'\t',time_list[i])
        print(op_list[i],'\t',time_list[i], file=fd_out)
        if time_sum > total_time*0.9 and found_90_flag==False:
            found_90_flag = True
            print('----Above op takes over 90% time----')
            print('----Above op takes over 90% time----', file=fd_out)
        if time_sum > total_time*0.95 and found_95_flag==False:
            found_95_flag = True
            print('----Above op takes over 95% time----')
            print('----Above op takes over 95% time----', file=fd_out)
        

    print('======Choosen op percentage======')
    print('======Choosen op percentage======',file=fd_out)
    print('total node: %d, choose op: %d, percent: %f'%(
                    total_node_cnt, 
                    choose_op_cnt,
                    (choose_op_cnt/ total_node_cnt)))
    print('total time: %d, choose time: %d, percent: %f'%(
                    total_time, 
                    choose_op_time,
                    (choose_op_time/ total_time)))
    print(model, file=fd_out)
    print('total node: %d, choose op: %d, percent: %f'%(
                    total_node_cnt, 
                    choose_op_cnt,
                    (choose_op_cnt/ total_node_cnt)), file=fd_out)
    print('total time: %d, choose time: %d, percent: %f'%(
                    total_time, 
                    choose_op_time,
                    (choose_op_time/ total_time)), file=fd_out)
    fd_out.close()


            