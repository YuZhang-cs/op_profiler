import tensorflow as tf

#=====================================
# General path settings
#=====================================
tf.app.flags.DEFINE_string('basic_graph', 
                        './basic_graphs/online_profiling.pbtxt',
                        #'./basic_graphs/online_profiling_cpu.pbtxt',
                        """The basic graph to generate profiling graph """)
tf.app.flags.DEFINE_integer('save_op_step_result', 
                        0,
                        """If 1, will save each step result of op test """)
tf.app.flags.DEFINE_string('step_result_path', 
                        './step_result/',
                        """path to save step result, each op in a file""")
tf.app.flags.DEFINE_integer('save_op_test_graph', 
                        0,
                        """If true, will save op test graph to test_graph.pbtxt """)
#=====================================
# Single model profiling path
#=====================================
tf.app.flags.DEFINE_string('model_name', 
                        'alexnet',
                        """The name of model, used to generate output filename """)
tf.app.flags.DEFINE_string('model_path', 
                        'test_graphs/baseline_graphs/alexnet_bsDefault_gpunum1_partitionGraph_0.pbtxt',
                        """The dir of pbtxt graph file """)
tf.app.flags.DEFINE_string('result_dir', 
                        'baseline_graphs_result/alexnet/',
                        """The detail result dir """)
tf.app.flags.DEFINE_string('overall_output', 
                        'baseline_result/graphs_overall.txt',
                        """The output file """)
#=====================================
# Multi model profiling path
#=====================================
tf.app.flags.DEFINE_string('multi_model_path', 
                        'test_graphs/GraphSharing/',
                        #'./basic_graphs/online_profiling_cpu.pbtxt',
                        """The dir of models, for multi model profiling """)
tf.app.flags.DEFINE_string('multi_model_result_dir', 
                        'graph_sharing_result/',
                        """The result dir for multi model profiling""")
tf.app.flags.DEFINE_string('multi_model_overall_output', 
                        'graph_sharing_overall.txt',
                        """The overall output file for multi model profiling""")
#=====================================
# Profiling Settings
#=====================================
tf.app.flags.DEFINE_integer('all_on_gpu',
                        0,
                        """If set 1, all node will be located to GPU0""")
tf.app.flags.DEFINE_integer('test_chain_len', 
                        10,
                        """The len of test op chain in test graph """)
tf.app.flags.DEFINE_integer('test_warmup_steps', 
                        5,
                        """The warm up steps of test graph""")
tf.app.flags.DEFINE_integer('test_run_steps', 
                        20,
                        """The total profiling steps of test graph, including warmup""")
tf.app.flags.DEFINE_integer('enable_timeline', 
                        0,
                        """Set to 1 to enable timeline in profiling""")
tf.app.flags.DEFINE_string('timeline_path', 
                        './profiling_timelines/',
                        """The dir to save timeline, each op in its own sub-dir""")
tf.app.flags.DEFINE_integer('use_timeline_prof', 
                        0,
                        """Set to 1 to use timeline to do profiling""")
#=====================================
# Auto tuning parameters
#=====================================
tf.app.flags.DEFINE_integer('chain_len_auto_tune',
                        0,
                        """If set 1, profiler will auto tune test chain len \
                            according to ideal_step_sec and ideal_step_range_ratio""")
tf.app.flags.DEFINE_float('ideal_step_sec', 
                        0.5,
                        """The ideal step time in seconds for each op""")
tf.app.flags.DEFINE_float('step_time_range_ratio', 
                        0.5,
                        """The relative range of step time. E.g. \
                            0.2 means [ideal*(1-0.2), ideal*(1+0.2)]""")
tf.app.flags.DEFINE_integer('max_tune_cnt',
                        3,
                        """In one auto tune, it can maximum change the \
                        len of op chain to 10x. This param defines the max tune times""")
tf.app.flags.DEFINE_integer('max_graph_mem_size',
                        8*1024*1024*1024,
                        """Maximum test graph size for auto tune module \
                        It will estimate op size to avoid OOM""")
tf.app.flags.DEFINE_integer('min_chain_len',
                        5,
                        """Minimum test chain len""")
#=====================================
# Statistics parameters
#=====================================
tf.app.flags.DEFINE_integer('outlier_filter_medium',
                        0,
                        """Filter outlier results that far form medium value""")
tf.app.flags.DEFINE_float('outlier_filter_medium_range',
                        0.2,
                        """allow range: medium * (1 +- range)""")
#=====================================
# DEBUG
#=====================================
tf.app.flags.DEFINE_string('profiling_graph_path', 
                        './profiling_graph/',
                        """The real profiling execution graph """)
tf.app.flags.DEFINE_integer('save_profiling_graph',
                        0,
                        """Set 1 if want to save profiling graph for debug""")

ENDPOINT_NODE_NAME = 'online_profiling_end_node__'
STARTPOINT_NODE_NAME = 'online_profiling_start_node__'

class InputDescriptor():
    def __init__(self, input_node=None, input_tensor=None, is_shape_input=False):
        self.is_const = False
        self.is_content_depend = False
        self.is_reference = False
        self.origin_node = input_node
        self.origin_tensor = input_tensor
        self.shape = None
        self.type = tf.float32 # Default is float type

        # If true, means that this input means the shape of the input tensor.
        # This happens if we use op 'Shape' to get shape of tensor X, then 
        # op Y takes output of op 'Shape' as input.
        self.is_shape_input = is_shape_input
        self.parse_node()
    
    def parse_node(self):
        if self.origin_node != None and self.origin_tensor != None:
            if self.origin_node.op == 'Const':
                self.is_const = True
            else:
                self.is_const = False
            self.shape = self.origin_tensor.get_shape().as_list()
            if 'Variable' not in self.origin_node.op:
                self.type = self.origin_tensor.dtype
            else:
                self.type = self.origin_node.attr['dtype'].type

        
        
        

