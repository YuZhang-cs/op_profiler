import tensorflow as tf
import modify_test_graph as mod
import profiling as profiling

test_filename = 'test_graph.pbtxt'
final_tensor_list = ['test_op']
for i in range(1,100):
    final_tensor = 'test_op_' + str(i)
    final_tensor_list.append(final_tensor)

graph_def = mod.load_protobuf_from_file(test_filename)
profiling.profiling(graph_def, final_tensor_name=final_tensor_list,
                test_op_chain_len=100,
                generate_timeline=True
                )