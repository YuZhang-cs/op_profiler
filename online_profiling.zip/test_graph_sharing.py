import sys

#from src import node_define
import modify_test_graph as mod
import online_profiling
import tensorflow as tf

import json
import os
import horovod.tensorflow as hvd
FLAGS = tf.app.flags.FLAGS
'''
tf.app.flags.DEFINE_string('model_path', 
                        'test_graphs/jf_graphs/',
                        #'./basic_graphs/online_profiling_cpu.pbtxt',
                        """The dir of models """)
tf.app.flags.DEFINE_string('result_dir', 
                        'jf_graphs_result/',
                        """The detail result dir """)
tf.app.flags.DEFINE_string('output_file', 
                        'jf_graphs_overall.txt',
                        """The output file """)
'''

def test_all_models(model_path='test_graphs/GraphSharing/',
                result_dir = 'graph_sharing_result/'):
    filetree = os.walk(model_path)
    all_result = []
    if not os.path.exists(result_dir):
        os.makedirs(result_dir)
    for path, dirList, fileList in filetree:
        for fileName in fileList:
            fileFullName = os.path.join(path,fileName)
            print('[DEBUG] Check file: ', fileFullName)
            if fileName!= 'run_graph.pbtxt':
                continue
            print('[DEBUG] open file: ', fileFullName)
            graph_def = mod.load_protobuf_from_file(fileFullName)
            model_name = fileFullName.split(model_path)[-1]
            #model_name = model_name.split('/original/')[0]
            model_name = model_name.replace('/','_')
            result_filename = result_dir + '/' + model_name + '_profiling.csv'
            log_filename = result_dir + 'log_' + model_name + '.txt'
            step_result_path = FLAGS.step_result_path + '/' + model_name + '/'
            if not os.path.exists(step_result_path):
                os.makedirs(step_result_path)
            result = online_profiling.graph_profiling(graph_def,
                            result_filename = result_filename,
                            step_result_path = step_result_path,
                            fail_log_filename = log_filename)
            all_result.append((model_name, result))
    return all_result

if __name__ == '__main__':
    output_file = FLAGS.multi_model_overall_output
    model_path = FLAGS.multi_model_path
    result_dir = FLAGS.multi_model_result_dir
    all_result = test_all_models(model_path = model_path,
                    result_dir = result_dir)
    with open(output_file, 'w') as fd_out:
        fd_out.write('| --- | pass | fail | total | coverage% |\n')
        fd_out.write('| --- | --- | --- | --- | --- |\n')
        for i in range(len(all_result)):
            model_name, result = all_result[i]
            fd_out.write('| %s | %d | %d | %d | %.2f |\n' % (
                model_name,
                result[0],
                result[1],
                result[2],
                result[3])
                )

