import os
import json
import pytest
import tensorflow as tf
from google.protobuf import text_format
from plan.adapter.tf_parser import TFNodeAttrParser, TFParser, ParserError
from plan.profiler.profiler import TFProfiler
from plan.profiler.database_loader import DatabaseLoader

TEST_DAG_FILE = './data/jf_graphs_result/vgg16.pbtxt'
TEST_PROFILING_FILE = './data/jf_graphs_result/vgg16_profiling.csv'
TEST_DB_FILE = './data/jf_graphs_result/vgg16_db.json'

def load_protobuf_from_file(filename, proto=tf.GraphDef()):
    with open(filename, 'r') as fdin:
        file_content = fdin.read()
        try:
            graph_def = text_format.Parse(file_content, tf.GraphDef())
            return graph_def
        except text_format.ParseError as e:
            raise IOError("Cannot parse file %s: %s." 
                            % (filename, str(e)))
    return graph_def

def get_node_by_name(graph_def, node_name, node_id_dict = None):
    target_node = None
    if node_id_dict == None:
        for node in graph_def.node:
            if node.name == node_name:
                return node
    else:
        idx = node_id_dict[node_name]
        node = graph_def.node[idx]
        return node
    return None

def analyze_input(graph_def):
    node_list = graph_def.node
    tf.reset_default_graph()
    tf.import_graph_def(graph_def, name='')
    print('Start analyzing input of nodes...')
    node_input_tensors_dict = {}
    with tf.Session() as sess:
        graph = sess.graph
        sess.graph.as_default()
        tf.initialize_all_variables().run()
        node_idx = 0
        total_nodes = len(node_list)
        for node in node_list:
            #print('[DEBUG] Analyzing the input tensor of node: %s' % node.name)
            if node_idx % 10000 == 1:
                print('Analyzed %d / %d' % (node_idx-1, total_nodes))
            node_input_tensors_dict[node.name] = []
            input_node_ok_flag = True
            try:
                for input_name in node.input:
                    # Deal with special input name
                    if input_name[0] == '^':
                        continue
                    elif ':' not in input_name:
                        input_tensor_name = input_name + ':0'
                    else:
                        input_tensor_name = input_name
                    try:
                        input_tensor = graph.get_tensor_by_name(input_tensor_name)
                    except:
                        print('cannot find tensor:', input_tensor_name)
                        input_tensor = None
                    if input_tensor != None:
                        try:
                            input_shape = input_tensor.get_shape().as_list()
                        except:
                            input_shape = []
                    else:
                        input_shape = []
                    node_input_tensors_dict[node.name].append(input_shape)
            except:
                print("Fail in parsing input of node " + node.name)
                input_node_ok_flag = False
                traceback.print_exc()
    print('Analyzing input of nodes finished!')
    return node_input_tensors_dict

def load_profiling_csv(filename):
    profiling_result = {}
    with open(filename, 'r') as fd_in:
        lines = fd_in.readlines()
    for line in lines:
        line_content = line.replace('\n','').split(',')
        if len(line_content) != 3:
            continue
        op_name = line_content[0]
        avg = float(line_content[1])
        std_err = float(line_content[2])
        result = {'avg': avg, 'std_err': std_err}
        profiling_result[op_name] = result
    return profiling_result

def test_tf_db():
    print('Start create db')
    if not os.path.exists(TEST_DB_FILE):
        with open(TEST_DB_FILE, 'w') as fd:
            fd.write('{}')

    db = DatabaseLoader(db_file_path=TEST_DB_FILE)
    parser = TFParser()
    standard_path = TEST_DAG_FILE
    graph_def = load_protobuf_from_file(TEST_DAG_FILE)

    profiling_result = load_profiling_csv(TEST_PROFILING_FILE)
    node_input_tensors_dict = analyze_input(graph_def)
    nodelist = parser.parse_graphs_for_profiling([standard_path],
                                                 devices=[1])
    
    #print('Test node 0')
    #node = nodelist[0]
    #result = profiler.get_node_execution_time(node)
    #assert(result['avg'] == 10.0)
    print('Start transforming records...')
    repeat_node_cnt = 0
    for node in nodelist:
        name = node['name']
        #print('[DEBUG] Transforming record of node: %s' % name)
        input_shape_list = node_input_tensors_dict[name]
        attr_list = node['attr_list']
        if name in profiling_result:
            result_dict = profiling_result[name]
        else:
            print('[DEBUG] No profiling result of node: %s' % name)
            continue
        op = node['op']
        if db.search_record(op=op, input_shape_list=input_shape_list,
                    attr_list=attr_list) != None:
            print('[DEBUG] Existed node: %s' % name)
            repeat_node_cnt += 1

        db.add_record(op=op, 
                    input_shape_list=input_shape_list,
                    attr_list=attr_list,
                    result_dict=result_dict)
    print('Completed.')
    print('Repeat node: %d' % repeat_node_cnt)
if __name__ == "__main__":
    test_tf_db()