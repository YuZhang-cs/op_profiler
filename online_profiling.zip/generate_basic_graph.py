'''
Generate a basic graph, then use another module to modify this graph and 
construct test graph.

Command to dump C graph: 
TF_DUMP_GRAPH_PREFIX=/home/v-zegao/adding_an_op/dump \
TF_CPP_MIN_VLOG_LEVEL=4 python test.py
'''

import tensorflow as tf

def gen_single_input_graph (shape_x = [32, 512, 512, 32],
                            minval=0, 
                            maxval=1,
                            dtype = tf.dtypes.float32,
                            op = tf.nn.relu):
    data_0 = tf.random.uniform(shape_x, minval, maxval, dtype, name='data_0')
    test_op = op(data_0, name='test_op')
    with tf.Session() as sess:
        sess.run(test_op)
    return

def gen_matmul_graph(  shape_x=[512, 1024], 
                                shape_y=[1024, 256],
                                minval=0, 
                                maxval=1,
                                dtype=tf.dtypes.float32,
                                op=tf.linalg.matmul
                            ):
    data_0 = tf.random.uniform(shape_x, minval, maxval, dtype, name='data_0')
    data_1 = tf.random.uniform(shape_y, minval, maxval, dtype, name='data_1')
    test_op = op(data_0, data_1, name='test_op')

    #for i in range(1,3):
    #    op = tf.math.multiply(data_0, op, name='op_' + str(i))
    
    with tf.Session() as sess:
        sess.run(test_op)

def gen_elewise_binary_graph(  shape_x=[1, 512, 512, 1], 
                                shape_y=[1, 512, 512, 1],
                                minval=0, 
                                maxval=1,
                                dtype=tf.dtypes.float32,
                                op=tf.math.multiply
                            ):
    data_0 = tf.random.uniform(shape_x, minval, maxval, dtype, name='data_0')
    data_1 = tf.random.uniform(shape_y, minval, maxval, dtype, name='data_1')
    test_op = op(data_0, data_1, name='test_op')
    #for i in range(1,3):
    #    op = tf.math.multiply(data_0, op, name='op_' + str(i))

    with tf.Session() as sess:
        sess.run(test_op)

def gen_conv2d_graph(input_size = [64, 256, 256, 3],
                    filter_size = [16,16,3,3],
                    strides = [1,1,1,1],
                    padding = 'SAME',
                    dilations = [1,1,1,1],
                    data_type = tf.dtypes.float32
                    ):
    data_0 = tf.random.uniform(input_size, 0, 10, data_type, name='data_0')
    filter_var = tf.truncated_normal(filter_size, stddev=0.5, name='filter')
    
    test_op = tf.nn.conv2d(input = data_0,
                    filter = filter_var,
                    strides = strides,
                    padding = padding,
                    dilations = dilations,
                    name = 'test_op')

    with tf.Session() as sess:
        sess.run(test_op)

def gen_maxpool_graph(input_size = [64, 256, 256, 3],
                    kernel_size = [1,4,4,1],
                    strides = [1,1,1,1],
                    padding = 'SAME',
                    data_type = tf.dtypes.float32):
    data_0 = tf.random.uniform(input_size, 0, 10, data_type, name='data_0')
    test_op = tf.nn.max_pool(data_0, kernel_size, strides, padding, 
                    name='test_op')
    with tf.Session() as sess:
        sess.run(test_op)

if __name__ == '__main__':
    #gen_elewise_binary_graph(op=tf.math.add)
    #gen_conv2d_graph()
    #gen_single_input_graph()
    gen_maxpool_graph()
