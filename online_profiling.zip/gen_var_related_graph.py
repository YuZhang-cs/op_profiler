import tensorflow as tf
import modify_test_graph as mod

def gen_graph_Variable(node, chain_len=1000):
    tf.reset_default_graph()
    # get shape
    shape = []
    shape_def = node.attr['shape'].shape.dim
    for dim in shape_def:
        shape.append(int(dim.size))
    if len(shape) == 0:
        shape = [1]
    #print('dtype: ', dtype)
    # gen init value
    dtype = node.attr['dtype'].type
    if dtype == tf.dtypes.float32 or dtype == tf.dtypes.half or \
                    dtype == tf.dtypes.float64:
        initial_value = tf.truncated_normal(shape, 0.0, 0.001,dtype=dtype)
    elif dtype == tf.dtypes.int32 or dtype == tf.dtypes.int64:
        initial_value = tf.ones(shape, dtype=dtype)
    else:
        print("Undefined dtype!", dtype)
        return None
    print('Prepare ready!')
    # gen op chain
    endpoint_tensor = []
    for i in range(chain_len):
        op_name = 'test_op_' + str(i)
        var = tf.Variable(  initial_value=initial_value,
                            dtype = dtype,
                            name = op_name)
        endpoint_tensor.append(op_name)
    return endpoint_tensor

def gen_graph_Assign(node, input_desc_list, chain_len=1000):
    tf.reset_default_graph()
    # get shape
    shape = []
    var_node = input_desc_list[0].origin_node
    value_node = input_desc_list[1].origin_node
    shape_def = value_node.attr['shape'].shape.dim
    for dim in shape_def:
        shape.append(int(dim.size))
    if len(shape) == 0:
        shape = [1]
    # gen value
    dtype = var_node.attr['dtype'].type
    if dtype == tf.dtypes.float32 or dtype == tf.dtypes.half or \
                    dtype == tf.dtypes.float64:
        initial_value = tf.truncated_normal(shape, 0.0, 0.001,dtype=dtype)
    elif dtype == tf.dtypes.int32 or dtype == tf.dtypes.int64:
        initial_value = tf.ones(shape, dtype=dtype)

    else:
        print("Undefined dtype!", dtype)
        return None
    # gen target variable
    var_op_name = 'online_profiling/var_node__'
    var = tf.Variable(  initial_value=initial_value,
                        dtype = dtype,
                        name = var_op_name)
    # gen op chain
    endpoint_tensor = []
    for i in range(chain_len):
        op_name = 'test_op_' + str(i)
        var = tf.assign(var,
                        value = initial_value,
                        name = op_name)
        endpoint_tensor.append(op_name)
    
    debug_save_graph_filename = 'test_graph.pbtxt'
    graph_def = tf.get_default_graph().as_graph_def()
    mod.save_protobuf_to_file(graph_def, debug_save_graph_filename)
    return endpoint_tensor


if __name__ == '__main__':
    graph_def = mod.load_protobuf_from_file('test_graphs/validation.pbtxt')
    for node in graph_def.node:
        if 'Variable' in node.op:
            tf.reset_default_graph()
            endpoint_tensor =  gen_graph_Variable(node, 10)
            print(endpoint_tensor)
            with tf.train.MonitoredTrainingSession() as sess:
                sess.run(endpoint_tensor)
            print('Run success!')

    