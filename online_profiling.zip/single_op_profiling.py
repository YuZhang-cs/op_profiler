from google.protobuf import text_format
import os
#os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID"
#os.environ["CUDA_VISIBLE_DEVICES"]="1"
import tensorflow as tf
from profiling import *
from tensorflow.python.platform import gfile
import time
import math
import modify_test_graph as mod
import generate_basic_graph as gen
from random import choice
from random import randint
import traceback
import online_prof_define


global_step_time_list = []
global_op_time_list = []
FLAGS = tf.app.flags.FLAGS
MEMORY_TO_USE = 8 * 1024 * 1024 * 1024  # In Byte, suppose can use 4GB

def profiling_matmul(origin_graph_name, n_range, k_range, m_range,
                        op_chain_len=100,
                        test_steps=20,
                        result_dir='op_prof_result/'):
    if FLAGS.enable_timeline == 1:
        enable_timeline = True
    else:
        enable_timeline = False
    if not os.path.exists(result_dir):
        os.makedirs(result_dir)
    if FLAGS.timeline_path[-1] != '/':
        timeline_path = FLAGS.timeline_path + '/' + 'MatMul'
    else:
        timeline_path = FLAGS.timeline_path + 'MatMul'
    for n in n_range:
        for m in m_range:
            for k in k_range:
                modify_shape_list = []
                modify_shape_list.append(['data_0/shape', [n,k]])
                modify_shape_list.append(['data_1/shape', [k,m]])
                print("Shape: %d_%d_%d" % (n, k, m))
                result_filename = '%s/MatMul_%d_%d_%d.csv' % (result_dir,n,k,m)
                single_profiling_test(  
                    origin_graph_filename=origin_graph_name,
                    modify_shape_list=modify_shape_list,
                    test_op='MatMul',
                    test_op_chain_length=op_chain_len,
                    warmup_steps=int(test_steps/4),
                    test_steps=test_steps,
                    result_filename=result_filename,
                    enable_timeline=enable_timeline,
                    timeline_path=timeline_path
                    )

def profiling_single_input(origin_graph_name, test_op, 
                            n_range = [64], 
                            h_range = [64],
                            w_range = [64], 
                            c_range=[64],
                            op_chain_len=100,
                            test_steps=20,
                            result_dir='op_prof_result/'):
    if FLAGS.enable_timeline == 1:
        enable_timeline = True
    else:
        enable_timeline = False
    if FLAGS.timeline_path[-1] != '/':
        timeline_base_path = FLAGS.timeline_path + '/'
    else:
        timeline_base_path = FLAGS.timeline_path
    if not os.path.exists(result_dir):
        os.makedirs(result_dir)
    for n in n_range:
        for h in h_range:
            for w in w_range:
                for c in c_range:
                    modify_shape_list = []
                    modify_shape_list.append(['data_0/shape', [n, h, w, c]])
                    timeline_path = timeline_base_path + '%s_%d_%d_%d_%d/' % \
                            (test_op,n,h,w,c)
                    result_filename = result_dir+'%s_%d_%d_%d_%d.csv' % \
                            (test_op,n,h,w,c)
                    single_profiling_test(
                        origin_graph_filename=origin_graph_name,
                        modify_shape_list=modify_shape_list,
                        test_op=test_op,
                        test_op_chain_length=op_chain_len,
                        warmup_steps=int(test_steps/4),
                        test_steps=test_steps,
                        result_filename=result_filename,
                        enable_timeline=enable_timeline,
                        timeline_path=timeline_path
                    )
    return

'''
def profiling_elewise_binary(origin_graph_name, test_op, 
                            n_range = [1], 
                            h_range = [256],
                            w_range = [256], 
                            c_range=[1],
                            test_steps=20,
                            op_chain_len=1000,
                            result_dir = 'op_prof_result/'):
    if FLAGS.enable_timeline == 1:
        enable_timeline = True
    else:
        enable_timeline = False
    if FLAGS.timeline_path[-1] != '/':
        timeline_path = FLAGS.timeline_path + '/' + test_op
    else:
        timeline_path = FLAGS.timeline_path + test_op
    if not os.path.exists(result_dir):
        os.makedirs(result_dir)
    for n in n_range:
        for h in h_range:
            for w in w_range:
                for c in c_range:
                    modify_shape_list = []
                    modify_shape_list.append(['data_0/shape', [n, h, w, c]])
                    modify_shape_list.append(['data_1/shape', [n, h, w, c]])
                    result_filename = result_dir+'%s_%d_%d_%d_%d.csv' % \
                            (test_op,n,h,w,c)
                    single_profiling_test(  
                        origin_graph_filename=origin_graph_name,
                        modify_shape_list=modify_shape_list,
                        test_steps=test_steps,
                        test_op=test_op,
                        test_op_chain_length=op_chain_len,
                        result_filename=result_filename,
                        enable_timeline=enable_timeline,
                        timeline_path=timeline_path
                        )
'''

def profiling_elewise_binary(origin_graph_name, test_op, 
                            n_range, 
                            m_range,
                            op_chain_len=100,
                            test_steps=20,
                            result_dir = 'op_prof_result/'):
    if FLAGS.enable_timeline == 1:
        enable_timeline = True
    else:
        enable_timeline = False
    if FLAGS.timeline_path[-1] != '/':
        timeline_path = FLAGS.timeline_path + '/' + test_op
    else:
        timeline_path = FLAGS.timeline_path + test_op
    if not os.path.exists(result_dir):
        os.makedirs(result_dir)
    for n in n_range:
        for m in m_range:
            modify_shape_list = []
            modify_shape_list.append(['data_0/shape', [n, m]])
            modify_shape_list.append(['data_1/shape', [n, m]])
            result_filename = result_dir+'%s_%d_%d.csv' % \
                    (test_op, n, m)
            print("Data shape: %d_%d" % (n, m))
            single_profiling_test(  
                origin_graph_filename=origin_graph_name,
                modify_shape_list=modify_shape_list,
                test_op=test_op,
                test_op_chain_length=op_chain_len,
                warmup_steps=int(test_steps/4),
                test_steps=test_steps,
                result_filename=result_filename,
                enable_timeline=enable_timeline,
                timeline_path=timeline_path
                )

def profiling_pooling(origin_graph_name, test_op,
                    n = 64,
                    h = 64, 
                    w = 64, 
                    c = 3, 
                    ksize = [1,4,4,1], 
                    strides = [1,1,1,1], 
                    op_chain_len=100,
                    test_steps=20,
                    result_dir = 'result/'):
    if not os.path.exists(result_dir):
        os.makedirs(result_dir)
    graph_def = mod.load_protobuf_from_file(origin_graph_name)
    print("Loaded")
    mod.modify_data_shape(graph_def, 'data_0/shape', [n,h,w,c])
    print('Data shape modified')

    mod.modify_pooling_config(graph_def, 'test_op',ksize, strides)
    print('Pooling config modified')

    op_chain=mod.modify_test_graph(graph_def, test_op, op_chain_len)
    print('OP chain generated')

    mod.save_protobuf_to_file(graph_def)

    result_filename = result_dir+'%s_%d_%d_%d_%d_%d_%d_%d_%d.csv' % \
                    (test_op,n,h,w,c,
                    ksize[1], ksize[2],
                    strides[1], strides[2])
    profiling(graph_def, int(test_steps/4), test_steps, final_tensor_name=op_chain, output_filename = result_filename)

def profiling_conv2d_exec(origin_graph_name, test_op = 'Conv2D',
                    n=64, h=256, w=256, c=3, f_x=3, f_y=3, f_c=1,
                    strides=[1,1,1,1], # in nhwc format
                    dilation=[1,1,1,1], 
                    op_chain_len=100,
                    test_steps=20,
                    nchw=False, # if true, this function will convert all data to nchw.
                    result_dir = 'op_prof_result/'):
                    
    graph_def = mod.load_protobuf_from_file(origin_graph_name)
    print("Loaded")
    if not os.path.exists(result_dir):
        os.makedirs(result_dir)
    if FLAGS.enable_timeline == 1:
        enable_timeline = True
    else:
        enable_timeline = False
    if FLAGS.timeline_path[-1] != '/':
        timeline_path = FLAGS.timeline_path + '/' + test_op
    else:
        timeline_path = FLAGS.timeline_path + test_op

    out_h = (h + strides[1] - 1) // strides[1]
    out_w = (w + strides[2] - 1) // strides[2]

    mod.modify_data_shape(graph_def, 'data_0/shape', [n,c,h,w])
    print('Data shape modified')
    mod.modify_data_shape(graph_def, 'filter/shape', [f_x,f_y,c,f_c])
    print('Filter shape modified')
    # For Conv2D, there is no data_1, this modify has no effect.
    mod.modify_data_shape(graph_def, 'data_1/shape', [n,f_c,out_h,out_w])
    print('Output shape modified')

    # Change stride to nchw format
    stride_h = strides[1]
    stride_w = strides[2]
    stride_c = strides[3]
    strides[1] = stride_c
    strides[2] = stride_h
    strides[3] = stride_w

    # Change dilation to nchw format
    dilation_h = dilation[1]
    dilation_w = dilation[2]
    dilation_c = dilation[3]
    dilation[1] = dilation_c
    dilation[2] = dilation_h
    dilation[3] = dilation_w

    mod.modify_conv2d_config(graph_def, 'test_op',dilation, strides)

    op_chain = mod.modify_test_graph(graph_def, test_op, op_chain_len)
    print('OP chain generated')

    mod.save_protobuf_to_file(graph_def)

    print("%d_%d_%d_%d_%d_%d_%d_%d_%d_%d" %(n, h, w, c,f_x,f_y,f_c,stride_h,stride_w,dilation_h))

    result_filename = result_dir+'%s_%d_%d_%d_%d_%d_%d_%d_%d_%d_%d.csv' % \
                    (test_op,n,h,w,c,f_x,f_y,f_c,
                    strides[1], strides[2], dilation[1])
    #if os.path.exists(result_filename):
    #    return
    profiling(graph_def, int(test_steps/4), test_steps, final_tensor_name=op_chain, output_filename = result_filename,
        test_op_chain_len=op_chain_len, enable_timeline=enable_timeline, timeline_path=timeline_path)

def get_chain_len(node_size):
    chainlen = int(MEMORY_TO_USE / node_size)
    if chainlen > 500:
        chainlen = 500
    #print('[DEBUG] max chain len: ', chainlen)
    return chainlen

def profile_binary(op_name, 
        m_range=range(256,10241,2), 
        n_range=range(256,10241,2),
        chain_len=100,
        test_steps=20,
        round_num=2000,
        result_dir='op_prof_result/normal/'):
    input_conb = []
   
    ''' remove duplicate inputs in op_prof_result/
    count = 0
    filetree = os.walk('op_prof_result/')
    for path, dirList, fileList in filetree:
        for filename in fileList:
            namelist = filename.replace('.csv','').split('_')
            input_conb.append(namelist[1] + '_' + namelist[2])
            count += 1
    round_num -= count
    '''

    i = 0
    while i < round_num:
        mc = [choice(m_range)]
        nc = [choice(n_range)]
        i += 1

        node_size = mc[0] * nc[0] * 4
        max_chain_len = get_chain_len(node_size)
        real_chain_len = min(chain_len, max_chain_len)
        if real_chain_len < 10:
            i -= 1
            continue

        ids = str(nc[0]) + '_' + str(mc[0])
        if ids in input_conb:
            i -= 1
            continue
        input_conb.append(ids)
        try:
            profiling_elewise_binary(
                    origin_graph_name='basic_graphs/elewise_binary.pbtxt',
                    test_op=op_name, 
                    n_range=nc, 
                    m_range=mc,
                    op_chain_len=real_chain_len,
                    test_steps=test_steps,
                    result_dir=result_dir)
        except:
            print(nc[0])
            print(mc[0])
            print("Meet error!")
            i -= 1
            input_conb.pop()
            traceback.print_exc()

def profile_matmul(n_range=[256,4097,2],
        k_range=[256,4097,2],
        m_range=[256,4097,2],
        chain_len=100,
        test_steps=20,
        round_num=2000,
        result_dir='op_prof_result/normal/'):
    op_name = 'MatMul'
    input_conb = []
    
    ''' remove duplicates
    count = 0
    with open('op_prof_result/MatMul.txt','r') as fin:
        for line in fin:
            namelist = line.split('_')
            input_conb.append(namelist[0] + '_' + namelist[1] + '_' + namelist[2])
            count += 1
    #round_num -= count
    '''
    i = 0
    while i < round_num:
        mc = [choice(m_range)]
        nc = [choice(n_range)]
        kc = [choice(k_range)]
        i += 1
        ids = str(nc[0]) + '_' + str(kc[0]) + '_' + str(mc[0])
        
        node_size = mc[0] * nc[0] * 4
        max_chain_len = get_chain_len(node_size)
        real_chain_len = min(chain_len, max_chain_len)
        if real_chain_len < 10:
            i -= 1
            continue
        if ids in input_conb:
            i -= 1
            continue
        input_conb.append(ids)
        try:
            profiling_matmul(
                    origin_graph_name='basic_graphs/matmul.pbtxt',
                     n_range=nc, 
                     k_range=kc, 
                     m_range=mc,
                     op_chain_len=real_chain_len,
                     test_steps=test_steps,
                     result_dir=result_dir)
        except:
            i -= 1
            print(nc[0])
            print(mc[0])
            print(kc[0])
            print("Meet error!")
            input_conb.pop()
            traceback.print_exc()

def profile_conv2d(n_range,
        h_range,
        w_range,
        c_range,
        f_xy_range,
        f_c_range,
        strides_range,
        dilation_range,
        chain_len=50,
        test_steps=20,
        round_num=2000,
        result_dir='op_prof_result/normal/',
        origin_graph_name='basic_graphs/conv2d.pbtxt',
        nchw=False,
        test_op='Conv2D',):
    input_conb = []
            
    cnt = 0
    while cnt < round_num:
        cnt += 1
        n_use = choice(n_range)
        h_use = choice(h_range)
        w_use = choice(w_range)
        c_use = choice(c_range)
        fxy_use = choice(f_xy_range)
        fc_use = choice(f_c_range)
        strides_use = choice(strides_range)
        dilation_use = choice(dilation_range)
        
        out_width = int((w_use - fxy_use)/strides_use) + 1
        out_height = int((h_use - fxy_use)/strides_use)+1
        node_size = n_use * out_width * out_height * fc_use * 4
        max_chain_len = get_chain_len(node_size)
        real_chain_len = min(chain_len, max_chain_len)

        idd = [n_use, h_use, w_use, c_use, fxy_use, fc_use, strides_use, dilation_use]
        if idd in input_conb:
            cnt -= 1
            continue
        if real_chain_len < 1:
            cnt -= 1
            continue
        input_conb.append(idd)
        try:
            profiling_conv2d_exec(
                    origin_graph_name=origin_graph_name,
                    test_op=test_op,
                    n=n_use,
                    h=h_use,
                    w=w_use,
                    c=c_use,
                    f_x=fxy_use,
                    f_y=fxy_use,
                    f_c=fc_use,
                    strides=[1,strides_use,strides_use,1],
                    dilation=[1,dilation_use,dilation_use,1],
                    op_chain_len=real_chain_len,
                    test_steps=test_steps,
                    nchw=nchw,
                    result_dir=result_dir)
        except:
            input_conb.pop()
            cnt -= 1
            print("Meet Error!")
            traceback.print_exc()
            
def profile_maxpool(n_range,
        h_range,
        w_range,
        c_range,
        k_range,
        stride_range,
        chain_len=100,
        test_steps=20,
        round_num=2000,
        result_dir='op_prof_result/normal/'):
    op_name = 'MaxPool'
    input_conb = []

    # remove duplicates
    #count = 0
    #filetree = os.walk('op_prof_result/')
    #for path, dirList, fileList in filetree:
    #    for filename in fileList:
    #        namelist = filename.replace('.csv','').split('_')
    #        input_conb.append(namelist[1] + '_' + namelist[2] + '_' + namelist[3])
    #        count += 1
    #round_num -= count

    i = 0
    while i < round_num:
        i += 1
        nc = [choice(n_range)]
        hc = [choice(h_range)]
        wc = [choice(w_range)]
        cc = [choice(c_range)]
        kc = [choice(k_range)]
        stc = [choice(stride_range)]
        print(str(nc[0]) + " " + str(hc[0])+ " " + str(wc[0]) + " "+ str(cc[0])+ ' ' + str(kc[0]) + ' ' + str(stc[0]))
        
        out_width = int((wc[0] - kc[0])/stc[0])+1
        out_height = int((hc[0] - kc[0])/stc[0])+1
        node_size = nc[0] * hc[0] * wc[0] * cc[0] * 4
        max_chain_len = get_chain_len(node_size)
        real_chain_len = min(chain_len, max_chain_len)
        if real_chain_len < 10:
            i -= 1
            continue
        if real_chain_len < 30:
            i -= 1
            continue

        ids = str(nc[0]) + '_' + str(hc[0]) + '_' + str(wc[0]) + '_' + str(cc[0]) + '_' + str(kc[0]) + '_' + str(stc[0])
        if ids in input_conb:
            i -= 1
            continue
        input_conb.append(ids)
        try:
            profiling_pooling(
                    origin_graph_name='basic_graphs/pool.pbtxt', 
                    test_op=op_name,
                    n=nc[0], 
                    h=hc[0], 
                    w=wc[0], 
                    c=cc[0], 
                    ksize=[1, kc[0], kc[0], 1], 
                    strides=[1, stc[0], stc[0], 1], 
                    op_chain_len=real_chain_len,
                    test_steps=test_steps,
                    result_dir=result_dir)
        except:
            print("Meet error!")
            i -= 1
            input_conb.pop()
            traceback.print_exc()
    
def profile_relu(n_range,
        h_range,
        w_range,
        c_range,
        chain_len=100,
        test_steps=20,
        round_num=2000,
        result_dir='op_prof_result/normal/'):
    op_name = 'Relu'
    input_conb = []
        
    ''' remove duplicates
    count = 0
    filetree = os.walk('op_prof_result/')
    for path, dirList, fileList in filetree:
        for filename in fileList:
            namelist = filename.replace('.csv','').split('_')
            input_conb.append(namelist[1] + '_' + namelist[2] + '_' + namelist[3] + '_' + namelist[4])
            count += 1
    round_num -= count
    '''

    i = 0
    while i < round_num:
        nc = [choice(n_range)]
        hc = [choice(h_range)]
        wc = [choice(w_range)]
        cc = [choice(c_range)]
        i += 1
        node_size = nc[0] * hc[0] * wc[0] * cc[0] * 4
        max_chain_len = get_chain_len(node_size)
        real_chain_len = min(chain_len, max_chain_len)
        if real_chain_len < 10:
            i -= 1
            continue
        if real_chain_len < 10:
            i -= 1
            continue
        print(str(nc[0]) + " " + str(hc[0])+ " " + str(wc[0]) + " "+ str(cc[0]))
        #if nc[0] * hc[0] * wc[0] * cc[0] > 1000000000:
        #    i -= 1
        #    continue
        ids = str(nc[0]) + '_' + str(hc[0]) + '_' + str(wc[0]) + '_' + str(cc[0])
        if ids in input_conb:
            i -= 1
            continue
        input_conb.append(ids)
        try:
            profiling_single_input(
                    origin_graph_name='basic_graphs/single_input.pbtxt', 
                    test_op=op_name,
                    n_range=nc, 
                    h_range=hc, 
                    w_range=wc, 
                    c_range=cc, 
                    op_chain_len=real_chain_len,
                    test_steps=test_steps,
                    result_dir=result_dir)
        except:
            print("Meet error!")
            i -= 1
            input_conb.pop()
            traceback.print_exc()

def prof_normal():
    #normal inputs
    profile_binary(
            op_name='Add',
            m_range=range(256,10241,2),
            n_range=range(256,10241,2),
            chain_len=100,
            test_steps=20,
            round_num=12000,
            result_dir='op_prof_result/normal/')


    profile_binary('Sub',range(256,10241,2),range(256,10241,2),100,20,12000,'op_prof_result/normal/')
    profile_binary('Mul',range(256,10241,2),range(256,10241,2),100,20,12000,'op_prof_result/normal/')
    profile_binary('RealDiv',range(256,10241,2),range(256,10241,2),100,20,12000,'op_prof_result/normal/')

    profile_matmul(
            n_range=range(256,4097,2),
            k_range=range(256,4097,2),
            m_range=range(256,4097,2),
            chain_len=100,
            test_steps=20,
            round_num=12000,
            result_dir='op_prof_result/normal/')

    profile_relu(
            n_range=range(8,257,2),
            h_range=range(16,513,2),
            w_range=range(16,513,2),
            c_range=[1,3]+list(range(16,257,2)),
            chain_len=100,
            test_steps=20,
            round_num=12000,
            result_dir='op_prof_result/normal/')

    profile_maxpool(
            n_range=range(8,257,2),
            h_range=range(16,513,2),
            w_range=range(16,513,2),
            c_range=[1,3]+list(range(16,257,2)),
            k_range=range(1,17,1),
            stride_range=range(1,17,1),
            chain_len=100,
            test_steps=20,
            round_num=12000,
            result_dir='op_prof_result/normal/')
    profile_conv2d(
            n_range=range(32,65,1),
            h_range=range(64,257,1),
            w_range=range(64,257,1),
            c_range=[1,3]+list(range(16,33,2)),
            f_xy_range=range(1,9,1),
            f_c_range=[1,3,5],
            strides_range=range(1,5,1),
            dilation_range=range(1,5,1),
            chain_len=20,
            test_steps=20,
            round_num=12000,
            result_dir='op_prof_result/normal/')
def prof_large():
    #large inputs
    profile_binary(
            op_name='Add',
            m_range=range(7168,10241,2),
            n_range=range(7168,10241,2),
            chain_len=100,
            test_steps=20,
            round_num=2000,
            result_dir='op_prof_result/large/')
    profile_binary('Sub',range(7168,10241,2),range(7168,10241,2),100,20,2000,'op_prof_result/large/') 
    profile_binary('Mul',range(7168,10241,2),range(7168,10241,2),100,20,2000,'op_prof_result/large/')
    profile_binary('RealDiv',range(7168,10241,2),range(7168,10241,2),100,20,2000,'op_prof_result/large/')
    
    profile_matmul(
            n_range=range(3072,4097,2),
            k_range=range(3072,4097,2),
            m_range=range(3072,4097,2),
            chain_len=100,
            test_steps=20,
            round_num=2000,
            result_dir='op_prof_result/large/')

    profile_relu(
            n_range=range(32,256,2),
            h_range=range(32,256,2),
            w_range=range(32,256,2),
            c_range=range(32,256,2),
            chain_len=100,
            test_steps=20,
            round_num=2000,
            result_dir='op_prof_result/large/')

    profile_maxpool(
            n_range=range(32,256,2),
            h_range=range(32,256,2),
            w_range=range(32,256,2),
            c_range=range(32,256,2),
            k_range=range(1,17,1),
            stride_range=range(1,9,1),
            chain_len=50,
            test_steps=20,
            round_num=2000,
            result_dir='op_prof_result/large/')

    profile_conv2d(
            n_range=range(32,65,1),
            h_range=range(64,512,1),
            w_range=range(64,512,1),
            c_range=range(32,65,2),
            f_xy_range=range(1,8,1),
            f_c_range=range(32,257,1),
            strides_range=range(1,3,1),
            dilation_range=range(1,3,1),
            chain_len=50,
            test_steps=20,
            round_num=2000,
            result_dir='op_prof_result/large/')

def prof_small():
    #small inputs
    profile_binary(
            op_name='Add',
            m_range=range(64,513,2),
            n_range=range(64,513,2),
            chain_len=1000,
            test_steps=100,
            round_num=2000,
            result_dir='op_prof_result/small/')
    profile_binary('Sub',range(64,513,2),range(64,513,2),1000,100,2000,'op_prof_result/small/')
    profile_binary('Mul',range(64,513,2),range(64,513,2),1000,100,2000,'op_prof_result/small/')
    profile_binary('RealDiv',range(64,513,2),range(64,513,2),1000,100,2000,'op_prof_result/small/')
    
    profile_matmul(
            n_range=range(64,257,2),
            k_range=range(64,257,2),
            m_range=range(64,257,2),
            chain_len=1000,
            test_steps=100,
            round_num=2000,
            result_dir='op_prof_result/small/')

def prof_bp():
    #normal inputs
    profile_conv2d(
            n_range=range(32,65,1),
            h_range=range(64,257,1),
            w_range=range(64,257,1),
            c_range=[1,3]+list(range(8,33,2)),
            f_xy_range=[1],
            f_c_range=[1,3]+list(range(16,33,2)),
            strides_range=range(1,5,1),
            dilation_range=range(1,5,1),
            chain_len=20,
            test_steps=20,
            round_num=12000,
            result_dir='op_prof_result/normal/',
            test_op='Conv2DBackpropInput',
            origin_graph_name='basic_graphs/conv2d_bp_input.pbtxt')
    profile_conv2d(
            n_range=range(32,65,1),
            h_range=range(64,257,1),
            w_range=range(64,257,1),
            c_range=[1,3]+list(range(8,33,2)),
            f_xy_range=[3],
            f_c_range=[1,3]+list(range(16,33,2)),
            strides_range=range(1,5,1),
            dilation_range=range(1,5,1),
            chain_len=20,
            test_steps=20,
            round_num=12000,
            result_dir='op_prof_result/normal/',
            test_op='Conv2DBackpropInput',
            origin_graph_name='basic_graphs/conv2d_bp_input.pbtxt')
    profile_conv2d(
            n_range=range(32,65,1),
            h_range=range(64,257,1),
            w_range=range(64,257,1),
            c_range=[1,3]+list(range(8,33,2)),
            f_xy_range=[1],
            f_c_range=[1,3]+list(range(16,33,2)),
            strides_range=range(1,5,1),
            dilation_range=range(1,5,1),
            chain_len=20,
            test_steps=20,
            round_num=12000,
            result_dir='op_prof_result/normal/',
            test_op='Conv2DBackpropFilter',
            origin_graph_name='basic_graphs/conv2d_bp_filter.pbtxt')
    profile_conv2d(
            n_range=range(32,65,1),
            h_range=range(64,257,1),
            w_range=range(64,257,1),
            c_range=[1,3]+list(range(8,33,2)),
            f_xy_range=[3],
            f_c_range=[1,3]+list(range(16,33,2)),
            strides_range=range(1,5,1),
            dilation_range=range(1,5,1),
            chain_len=20,
            test_steps=20,
            round_num=12000,
            result_dir='op_prof_result/normal/',
            test_op='Conv2DBackpropFilter',
            origin_graph_name='basic_graphs/conv2d_bp_filter.pbtxt')
    
    #small inputs
    profile_conv2d(
            n_range=range(16,64,1),
            h_range=range(16,64,1),
            w_range=range(16,64,1),
            c_range=[1,3]+list(range(8,33,2)),
            f_xy_range=[1],
            f_c_range=[1,3]+list(range(16,33,2)),
            strides_range=range(1,5,1),
            dilation_range=range(1,5,1),
            chain_len=20,
            test_steps=20,
            round_num=2000,
            result_dir='op_prof_result/small/',
            test_op='Conv2DBackpropInput',
            origin_graph_name='basic_graphs/conv2d_bp_input.pbtxt')
    profile_conv2d(
            n_range=range(16,64,1),
            h_range=range(16,64,1),
            w_range=range(16,64,1),
            c_range=[1,3]+list(range(8,33,2)),
            f_xy_range=[3],
            f_c_range=[1,3]+list(range(16,33,2)),
            strides_range=range(1,5,1),
            dilation_range=range(1,5,1),
            chain_len=20,
            test_steps=20,
            round_num=2000,
            result_dir='op_prof_result/small/',
            test_op='Conv2DBackpropInput',
            origin_graph_name='basic_graphs/conv2d_bp_input.pbtxt')
    profile_conv2d(
            n_range=range(16,64,1),
            h_range=range(16,64,1),
            w_range=range(16,64,1),
            c_range=[1,3]+list(range(8,33,2)),
            f_xy_range=[1],
            f_c_range=[1,3]+list(range(16,33,2)),
            strides_range=range(1,5,1),
            dilation_range=range(1,5,1),
            chain_len=20,
            test_steps=20,
            round_num=2000,
            result_dir='op_prof_result/small/',
            test_op='Conv2DBackpropFilter',
            origin_graph_name='basic_graphs/conv2d_bp_filter.pbtxt')
    profile_conv2d(
            n_range=range(16,64,1),
            h_range=range(16,64,1),
            w_range=range(16,64,1),
            c_range=[1,3]+list(range(8,33,2)),
            f_xy_range=[3],
            f_c_range=[1,3]+list(range(16,33,2)),
            strides_range=range(1,5,1),
            dilation_range=range(1,5,1),
            chain_len=20,
            test_steps=20,
            round_num=2000,
            result_dir='op_prof_result/small/',
            test_op='Conv2DBackpropFilter',
            origin_graph_name='basic_graphs/conv2d_bp_filter.pbtxt')

#NCHW Data
def prof_conv2dbp_nchw():
    #normal inputs
    profile_conv2d(
            n_range=[16],
            h_range=[32],
            w_range=[64],
            c_range=[8],
            f_xy_range=[3],
            f_c_range=[4],
            strides_range=range(1,5,1),
            dilation_range=range(1,5,1),
            chain_len=20,
            test_steps=20,
            round_num=1,
            result_dir='op_prof_nchw_result/small/',
            test_op='Conv2DBackpropFilter',
            nchw=True,
            origin_graph_name='basic_graphs/conv2d_bp_filter_nchw.pbtxt')
    
        #normal inputs
    profile_conv2d(
            n_range=range(32,65,1),
            h_range=range(64,257,1),
            w_range=range(64,257,1),
            c_range=[1,3]+list(range(8,33,2)),
            f_xy_range=[1],
            f_c_range=[1],
            strides_range=range(1,5,1),
            dilation_range=range(1,5,1),
            chain_len=20,
            test_steps=20,
            round_num=12000,
            result_dir='op_prof_nchw_result/normal/',
            test_op='Conv2DBackpropInput',
            nchw=True,
            origin_graph_name='basic_graphs/conv2d_bp_input_nchw.pbtxt')
    profile_conv2d(
            n_range=range(32,65,1),
            h_range=range(64,257,1),
            w_range=range(64,257,1),
            c_range=[1,3]+list(range(8,33,2)),
            f_xy_range=[3],
            f_c_range=[3],
            strides_range=range(1,5,1),
            dilation_range=range(1,5,1),
            chain_len=20,
            test_steps=20,
            round_num=12000,
            result_dir='op_prof_nchw_result/normal/',
            test_op='Conv2DBackpropInput',
            nchw=True,
            origin_graph_name='basic_graphs/conv2d_bp_input_nchw.pbtxt')
    profile_conv2d(
            n_range=range(32,65,1),
            h_range=range(64,257,1),
            w_range=range(64,257,1),
            c_range=[1,3]+list(range(8,33,2)),
            f_xy_range=[1],
            f_c_range=[1],
            strides_range=range(1,5,1),
            dilation_range=range(1,5,1),
            chain_len=20,
            test_steps=20,
            round_num=12000,
            result_dir='op_prof_nchw_result/normal/',
            test_op='Conv2DBackpropFilter',
            nchw=True,
            origin_graph_name='basic_graphs/conv2d_bp_filter_nchw.pbtxt')
    profile_conv2d(
            n_range=range(32,65,1),
            h_range=range(64,257,1),
            w_range=range(64,257,1),
            c_range=[1,3]+list(range(8,33,2)),
            f_xy_range=[3],
            f_c_range=[3],
            strides_range=range(1,5,1),
            dilation_range=range(1,5,1),
            chain_len=20,
            test_steps=20,
            round_num=12000,
            result_dir='op_prof_nchw_result/normal/',
            test_op='Conv2DBackpropFilter',
            nchw=True,
            origin_graph_name='basic_graphs/conv2d_bp_filter_nchw.pbtxt')
    
    #small inputs
    profile_conv2d(
            n_range=range(16,64,1),
            h_range=range(16,64,1),
            w_range=range(16,64,1),
            c_range=[1,3]+list(range(8,33,2)),
            f_xy_range=[1],
            f_c_range=[1],
            strides_range=range(1,5,1),
            dilation_range=range(1,5,1),
            chain_len=20,
            test_steps=20,
            round_num=2000,
            result_dir='op_prof_nchw_result/small/',
            test_op='Conv2DBackpropInput',
            nchw=True,
            origin_graph_name='basic_graphs/conv2d_bp_input_nchw.pbtxt')
    profile_conv2d(
            n_range=range(16,64,1),
            h_range=range(16,64,1),
            w_range=range(16,64,1),
            c_range=[1,3]+list(range(8,33,2)),
            f_xy_range=[3],
            f_c_range=[3],
            strides_range=range(1,5,1),
            dilation_range=range(1,5,1),
            chain_len=20,
            test_steps=20,
            round_num=2000,
            result_dir='op_prof_nchw_result/small/',
            test_op='Conv2DBackpropInput',
            nchw=True,
            origin_graph_name='basic_graphs/conv2d_bp_input_nchw.pbtxt')
    profile_conv2d(
            n_range=range(16,64,1),
            h_range=range(16,64,1),
            w_range=range(16,64,1),
            c_range=[1,3]+list(range(8,33,2)),
            f_xy_range=[1],
            f_c_range=[1],
            strides_range=range(1,5,1),
            dilation_range=range(1,5,1),
            chain_len=20,
            test_steps=20,
            round_num=2000,
            result_dir='op_prof_nchw_result/small/',
            test_op='Conv2DBackpropFilter',
            nchw=True,
            origin_graph_name='basic_graphs/conv2d_bp_filter_nchw.pbtxt')
    profile_conv2d(
            n_range=range(16,64,1),
            h_range=range(16,64,1),
            w_range=range(16,64,1),
            c_range=[1,3]+list(range(8,33,2)),
            f_xy_range=[3],
            f_c_range=[3],
            strides_range=range(1,5,1),
            dilation_range=range(1,5,1),
            chain_len=20,
            test_steps=20,
            round_num=2000,
            result_dir='op_prof_nchw_result/small/',
            test_op='Conv2DBackpropFilter',
            nchw=True,
            origin_graph_name='basic_graphs/conv2d_bp_filter_nchw.pbtxt')

def prof_conv2d_nchw():
    profile_conv2d(
            n_range=range(32,65,1),
            h_range=range(64,257,1),
            w_range=range(64,257,1),
            c_range=[1,3]+list(range(16,33,2)),
            f_xy_range=[1],
            f_c_range=[1,3]+list(range(16,33,2)),
            strides_range=range(1,5,1),
            dilation_range=range(1,5,1),
            chain_len=20,
            test_steps=20,
            round_num=12000,
            result_dir='op_prof_nchw_result/normal/',
            nchw=True,
            origin_graph_name='basic_graphs/conv2d_nchw.pbtxt')
    
    profile_conv2d(
            n_range=range(32,65,1),
            h_range=range(64,257,1),
            w_range=range(64,257,1),
            c_range=[1,3]+list(range(16,33,2)),
            f_xy_range=[3],
            f_c_range=[1,3]+list(range(16,33,2)),
            strides_range=range(1,5,1),
            dilation_range=range(1,5,1),
            chain_len=20,
            test_steps=20,
            round_num=12000,
            result_dir='op_prof_nchw_result/normal/',
            nchw=True,
            origin_graph_name='basic_graphs/conv2d_nchw.pbtxt')
    profile_conv2d(
            n_range=range(16,64,1),
            h_range=range(16,64,1),
            w_range=range(16,64,1),
            c_range=[1,3]+list(range(8,33,2)),
            f_xy_range=[1],
            f_c_range=[1,3]+list(range(16,33,2)),
            strides_range=range(1,5,1),
            dilation_range=range(1,5,1),
            chain_len=20,
            test_steps=20,
            round_num=2000,
            result_dir='op_prof_nchw_result/small/',
            nchw=True,
            origin_graph_name='basic_graphs/conv2d_nchw.pbtxt')
    profile_conv2d(
            n_range=range(16,64,1),
            h_range=range(16,64,1),
            w_range=range(16,64,1),
            c_range=[1,3]+list(range(8,33,2)),
            f_xy_range=[3],
            f_c_range=[1,3]+list(range(16,33,2)),
            strides_range=range(1,5,1),
            dilation_range=range(1,5,1),
            chain_len=20,
            test_steps=20,
            round_num=2000,
            result_dir='op_prof_nchw_result/small/',
            nchw=True,
            origin_graph_name='basic_graphs/conv2d_nchw.pbtxt')
    profile_conv2d(
            n_range=range(32,65,1),
            h_range=range(64,512,1),
            w_range=range(64,512,1),
            c_range=range(32,65,2),
            f_xy_range=[1],
            f_c_range=[1,3]+list(range(32,257,1)),
            strides_range=range(1,3,1),
            dilation_range=range(1,3,1),
            chain_len=20,
            test_steps=20,
            round_num=2000,
            result_dir='op_prof_result/large/',
            nchw=True,
            origin_graph_name='basic_graphs/conv2d_nchw.pbtxt')
    profile_conv2d(
            n_range=range(32,65,1),
            h_range=range(64,512,1),
            w_range=range(64,512,1),
            c_range=range(32,65,2),
            f_xy_range=[3],
            f_c_range=[1,3]+list(range(32,257,1)),
            strides_range=range(1,3,1),
            dilation_range=range(1,3,1),
            chain_len=20,
            test_steps=20,
            round_num=2000,
            result_dir='op_prof_result/large/',
            nchw=True,
            origin_graph_name='basic_graphs/conv2d_nchw.pbtxt')

conv2d_op_graph_list = [
    ('Conv2D', 'basic_graphs/conv2d_nchw.pbtxt'),
    ('Conv2DBackpropFilter', 'basic_graphs/conv2d_bp_filter_nchw.pbtxt'),
    ('Conv2DBackpropInput', 'basic_graphs/conv2d_bp_input_nchw.pbtxt')
]

def prof_conv2d_realdata(data, round_each_data=200, nchw=True):
    # Data: a recordlist [n,h,w,c,fx,fy,fc,strideh,stridew,dilation,time]
    for i in range(round_each_data):
        n = max(1, data[0] + randint(-5,5))
        h = max(1, data[1] + randint(-5,5))
        w = max(1, data[2] + randint(-5,5))
        c = max(1, data[3] + randint(-5,5))
        fxy = data[4]
        fc = max(1, data[6] + randint(-5,5))
        strides = data[7]
        dilation = max(1, data[8] + randint(-5,5))
        for (test_op, origin_graph_name) in conv2d_op_graph_list:
            profile_conv2d(
                n_range=[n],
                h_range=[h],
                w_range=[w],
                c_range=[c],
                f_xy_range=[fxy],
                f_c_range=[fc],
                strides_range=[strides],
                dilation_range=[dilation],
                chain_len=20,
                test_steps=20,
                round_num=1,
                result_dir='op_prof_nchw_result/real/',
                test_op=test_op,
                nchw=True,
                origin_graph_name=origin_graph_name)

def load_conv2d_realdata(filename):
    with open(filename, 'r') as fd_in:
        lines = fd_in.readlines()
    for line in lines:
        line_list = line.replace('\n','').split(',')
        for i in range(len(line_list)-2):
            line_list[i] = int(line_list[i])
        line_list[-2] = float(line_list[-2])
        prof_conv2d_realdata(line_list)

if __name__ == '__main__':
    load_conv2d_realdata('./jf_graphs_train_data/conv2d_fxy1_data.csv')
    load_conv2d_realdata('./jf_graphs_train_data/conv2d_fxy3_data.csv')