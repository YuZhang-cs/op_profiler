import modify_test_graph as mod

def statistic_one_model(model_name='resnet50')
    graph_file = ''
    profiling_result_file = ''
    graph = mod.load_protobuf_from_file(graph_file)

