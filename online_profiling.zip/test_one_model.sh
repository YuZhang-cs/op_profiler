#!/bin/bash
rm /tmp/online_profiling/*
rm log.txt
rm graph_profiling.csv
#python3 test_single_graph.py --model_path=test_graphs/baseline_graphs/nasnet.pbtxt --result_dir=baseline_graphs_result/nasnet/ --overall_output=baseline_graphs_result/overall.txt --save_op_step_result=0 --step_result_path=baseline_graphs_result/step_result/ --save_op_test_graph=0 --test_warmup_steps=3 --test_run_steps=15 --all_on_gpu=1 --test_chain_len=1000 --chain_len_auto_tune=1 --max_tune_cnt=1 --max_graph_mem_size=14000000000 --outlier_filter_medium=1 --save_profiling_graph=0

#python3 test_single_graph.py --model_path=test_graphs/baseline_graphs/seq2seq.pbtxt --result_dir=baseline_graphs_result/seq2seq/ --overall_output=baseline_graphs_result/overall.txt --save_op_step_result=0 --step_result_path=baseline_graphs_result/step_result/ --save_op_test_graph=0 --test_warmup_steps=3 --test_run_steps=15 --all_on_gpu=1 --test_chain_len=1000 --chain_len_auto_tune=1 --max_tune_cnt=1 --max_graph_mem_size=14000000000 --outlier_filter_medium=1 --save_profiling_graph=0

#python3 test_single_graph.py --model_path=test_graphs/baseline_graphs/lstm.pbtxt --result_dir=baseline_graphs_result/lstm/ --overall_output=baseline_graphs_result/overall.txt --save_op_step_result=0 --step_result_path=baseline_graphs_result/step_result/ --save_op_test_graph=0 --test_warmup_steps=3 --test_run_steps=15 --all_on_gpu=1 --test_chain_len=1000 --chain_len_auto_tune=1 --max_tune_cnt=1 --max_graph_mem_size=14000000000 --outlier_filter_medium=1 --save_profiling_graph=0

python3 test_single_graph.py --model_path=test_graphs/baseline_graphs/deepspeech.pbtxt --result_dir=baseline_graphs_result/deepspeech/ --overall_output=baseline_graphs_result/overall.txt --save_op_step_result=0 --step_result_path=baseline_graphs_result/step_result/ --save_op_test_graph=0 --test_warmup_steps=3 --test_run_steps=15 --all_on_gpu=1 --test_chain_len=1000 --chain_len_auto_tune=1 --max_tune_cnt=1 --max_graph_mem_size=10000000000 --outlier_filter_medium=1 --save_profiling_graph=0

#python3 test_single_graph.py --model_path=test_graphs/baseline_graphs/alexnet.pbtxt --result_dir=baseline_graphs_result/alexnet/ --overall_output=baseline_graphs_result/overall.txt --save_op_step_result=0 --step_result_path=baseline_graphs_result/step_result/ --save_op_test_graph=0 --test_warmup_steps=3 --test_run_steps=15 --all_on_gpu=1 --test_chain_len=1000 --chain_len_auto_tune=1 --max_tune_cnt=1 --max_graph_mem_size=14000000000 --outlier_filter_medium=1 --save_profiling_graph=0

#python3 test_single_graph.py --model_path=test_graphs/baseline_graphs/vgg16.pbtxt --result_dir=baseline_graphs_result/vgg16/ --overall_output=baseline_graphs_result/overall.txt --save_op_step_result=0 --step_result_path=baseline_graphs_result/step_result/ --save_op_test_graph=0 --test_warmup_steps=3 --test_run_steps=15 --all_on_gpu=1 --test_chain_len=100 --chain_len_auto_tune=1 --max_tune_cnt=1 --max_graph_mem_size=10000000000 --outlier_filter_medium=1 --save_profiling_graph=0

#python3 test_single_graph.py --model_path=test_graphs/baseline_graphs/resnet50.pbtxt --result_dir=baseline_graphs_result/resnet50/ --overall_output=baseline_graphs_result/overall.txt --save_op_step_result=0 --step_result_path=baseline_graphs_result/step_result/ --save_op_test_graph=0 --test_warmup_steps=3 --test_run_steps=15 --all_on_gpu=1 --test_chain_len=100 --chain_len_auto_tune=1 --max_tune_cnt=1 --max_graph_mem_size=10000000000 --outlier_filter_medium=1 --save_profiling_graph=0

#python3 test_single_graph.py --model_path=test_graphs/baseline_graphs/inception3.pbtxt --result_dir=baseline_graphs_result/inception3/ --overall_output=baseline_graphs_result/overall.txt --save_op_step_result=0 --step_result_path=baseline_graphs_result/step_result/ --save_op_test_graph=0 --test_warmup_steps=3 --test_run_steps=15 --all_on_gpu=1 --test_chain_len=100 --chain_len_auto_tune=1 --max_tune_cnt=1 --max_graph_mem_size=10000000000 --outlier_filter_medium=1 --save_profiling_graph=0

