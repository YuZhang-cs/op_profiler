'''
Patches for special ops.
'''
import modify_test_graph as mod
from online_prof_define import *
import traceback


# Return: input_ok_flag, input_desc_list
def inputFusedBatchNormGradV3(graph, target_graph_def, node, node_id_dict):
    input_node_ok_flag = True
    input_desc_list =[]
    input_id = -1
    try:
        for input_name in node.input:
            print('[DEBUG] Analyzing the input tensor: %s' % input_name)
            input_id += 1
            input_node_name = input_name
            # Takes which output tensor from input op, ':' in name
            input_tensor_id = 0
            # Deal with special input name
            if input_name[0] == '^':
                node.input[input_id] = '^' + STARTPOINT_NODE_NAME
                input_desc_list.append(None)
                input_node_name = input_name[1:]
                continue
            elif ':' not in input_name:
                input_tensor_name = input_name + ':0'
            else:
                input_tensor_name = input_name
                input_node_name = input_name.split(':')[0]
                input_tensor_id = int(input_name.split(':')[1])
            try:
                input_tensor = graph.get_tensor_by_name(input_tensor_name)
            except:
                print('cannot find tensor:', input_tensor_name)
                input_node_ok_flag = False
                return
            #input_shape = input_tensor.get_shape().as_list()
            input_node = mod.get_node_by_name(target_graph_def, input_node_name,
                            node_id_dict=node_id_dict)
            if 'Shape' in input_node.op:
                # If the input op is a shape op
                # Find the original op
                # Gen input desc with is_shape_input flag
                print('[DEBUG] Dealing with shape input')

                real_input_name = input_node.input[input_tensor_id]
                if ':' not in real_input_name:
                    input_tensor_name = real_input_name + ':0'
                input_node = mod.get_node_by_name(target_graph_def, real_input_name,
                                node_id_dict=node_id_dict)
                input_tensor = graph.get_tensor_by_name(input_tensor_name)
                input_desc = InputDescriptor(input_node, 
                                input_tensor, is_shape_input=True)
            else:
                if input_id!=5:
                    input_desc = InputDescriptor(input_node, input_tensor)
                else:
                    input_desc = InputDescriptor()
                    input_desc.shape=[0]
            input_desc_list.append(input_desc)
    except:
        print("Fail in parsing input of node " + node.name)
        input_node_ok_flag = False
        traceback.print_exc()
    return input_node_ok_flag, input_desc_list

special_input_ops = {'FusedBatchNormGradV3':inputFusedBatchNormGradV3}