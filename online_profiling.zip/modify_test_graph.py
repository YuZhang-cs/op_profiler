from google.protobuf import text_format
import tensorflow as tf
import copy
import numpy as np

BASIC_GRAPH_TEST_OP_NAME = 'test_op'
TEST_GRAPH_END_OP_NAME = 'online_profiling_end_node__'

dtype_dict = {
    tf.float32 : 1,
    tf.float64 : 2,
    tf.int32 : 3,
    tf.uint8 : 4,
    tf.int16 : 5,
    tf.int8 : 6,
    tf.string : 7,
    tf.complex64 : 8,  # Single-precision complex
    tf.int64 : 9,
    tf.bool : 10,
    tf.qint8 : 11,     # Quantized int8
    tf.quint8 : 12,    # Quantized uint8
    tf.qint32 : 13,    # Quantized int32
    tf.bfloat16 : 14,  # Float32 truncated to 16 bits.  Only for cast ops.
    tf.qint16 : 15,    # Quantized int16
    tf.quint16 : 16,   # Quantized uint16
    tf.uint16 : 17,
    tf.complex128 : 18,  # Double-precision complex
    tf.float16 : 19,
    tf.resource : 20,
    tf.variant : 21,  # Arbitrary C++ data types
    tf.uint32 : 22,
    tf.uint64 : 23,
}
'''
dtype_ref_to_common_dict = {
    tf.float32_ref : tf.float32,
    tf.float64_ref : tf.float64,
    tf.int32_ref : tf.int32,
    tf.uint8_ref : tf.uint8,
    tf.int16_ref : tf.int16,
    tf.int8_ref : tf.int8,
    tf.string_ref : tf.string,
    tf.complex64_ref : tf.complex64,  # Single-precision complex
    tf.int64_ref : tf.int64,
    tf.bool_ref : tf.bool,
    tf.qint8_ref : tf.qint8,     # Quantized int8
    tf.quint8_ref : tf.quint8,    # Quantized uint8
    tf.qint32_ref : tf.qint32,    # Quantized int32
    tf.bfloat16_ref : tf.bfloat16,  # Float32 truncated to 16 bits.  Only for cast ops.
    tf.qint16_ref : tf.qint16,    # Quantized int16
    tf.quint16_ref : tf.quint16,   # Quantized uint16
    tf.uint16_ref : tf.uint16,
    tf.complex128_ref : tf.complex128,  # Double-precision complex
    tf.float16_ref : tf.float16,
    tf.resource_ref : tf.resource,
    tf.variant_ref : tf.variant,  # Arbitrary C++ data types
    tf.uint32_ref : tf.uint32,
    tf.uint64_ref : tf.uint64,
}
'''
def dtype_ref_to_common(dtype):
    if dtype == tf.float32_ref:
        return tf.float32

def load_protobuf_from_string(raw_str, proto=tf.NodeDef()):
    try:
        node_def = text_format.Parse(raw_str, proto)
        return node_def
    except text_format.ParseError as e:
            raise IOError("Cannot parse string %s\nERR INFO: %s." 
                            % (raw_str, str(e)))
    return None

def load_protobuf_from_file(filename, proto=tf.GraphDef()):
    with open(filename, 'r') as fdin:
        file_content = fdin.read()
        try:
            graph_def = text_format.Parse(file_content, tf.GraphDef())
            return graph_def
        except text_format.ParseError as e:
            raise IOError("Cannot parse file %s: %s." 
                            % (filename, str(e)))
    return graph_def

def get_node_by_name(graph_def, node_name, node_id_dict = None):
    target_node = None
    if node_id_dict == None:
        for node in graph_def.node:
            if node.name == node_name:
                return node
    else:
        idx = node_id_dict[node_name]
        node = graph_def.node[idx]
        return node
    return None

def save_protobuf_to_file(protobuf, filename='test_graph.pbtxt'):
    with open(filename, 'w') as fdout:
        fdout.write(text_format.MessageToString(protobuf))

# Return the whole op chain
def create_op_chain(graph_def, source_node, chain_len, dtype=tf.float32):
    last_node = source_node
    op_chain = []
    op_chain.append('test_op')
    end_node = get_node_by_name(graph_def, TEST_GRAPH_END_OP_NAME)
    end_node.input.append(source_node.name)
    end_node.attr['N'].i = chain_len
    '''
    if 'dtype' in source_node.attr:
        end_node.attr['T'].type = source_node.attr['dtype'].type
    elif 'T' in source_node.attr:
        end_node.attr['T'].type = source_node.attr['T'].type
    '''
    end_node.attr['T'].type = dtype_dict[dtype]
    for i in range(1, chain_len):
        new_node = copy.deepcopy(source_node)
        new_node.name = 'test_op_' + str(i)
        #op_chain.append(new_node.name)

        new_node.input.append('^' + last_node.name)
        end_node.input.append(new_node.name)
        graph_def.node.append(new_node)
        last_node = new_node
    op_chain.append(end_node.name)
    return op_chain

# The type is int32 in corrent version.
def list_to_buffer(list_data):
    #data_size_node.tensor_content
    output_str = ''
    for data in list_data:
        for i in range(4):
            byte = data % 256
            byte_str = ''
            for j in range(3):
                byte_str = str(byte % 8) + byte_str
                byte = byte // 8
            byte_str = '\\' + byte_str
            output_str = output_str + byte_str
            data = data // 256
    print('[DEBUG] shape:%s, tensor_content:%s' % (str(list_data), output_str))
    return output_str

def modify_conv2d_config(graph_def, conv2d_node_name,
                        dilations_list = [1,1,1,1],
                        strides_list = [1,1,1,1]):
    node_list = graph_def.node
    conv2d_node = None
    for node in node_list:
        if node.name == conv2d_node_name:
            conv2d_node = node
    if conv2d_node == None:
        print('[ERROR in modify_conv2d_config] node %s not found' %
            conv2d_node_name)
        return
    conv2d_node.attr['dilations'].list.i[:] = dilations_list
    conv2d_node.attr['strides'].list.i[:] = strides_list

def modify_const_int(node, dim_list, new_value, dtype):
    raw_dim_list = node.attr['value'].tensor.tensor_shape.dim
    for i in range(dim_list):
        if len(raw_dim_list) > i:
            raw_dim_list[i].size = dim_list[i]
        else:
            new_dim = copy.deepcopy(raw_dim_list[0])
            new_dim.size = dim_list[i]
            raw_dim_list.append(new_dim)
    shape_ndarray = np.asarray(new_value, dtype=dtype)
    shape_buffer = shape_ndarray.tobytes()
    #print('[DEBUG] shape buffer: ', str(shape_buffer))
    node.attr['value'].tensor.tensor_content = shape_buffer

def modify_data_format(graph_def, node_name, data_format):
    node_list = graph_def.node
    modify_node = None
    for node in node_list:
        if node.name == node_name:
            modify_node = node
            break
    if modify_node == None:
        print('[ERROR in modify_data_format] node %s not found' %
            node_name)
        return
    modify_node.attr['data_format'].s=data_format

def modify_data_shape(graph_def, shape_node_name, new_shape):
    node_list = graph_def.node
    shape_node = None
    for node in node_list:
        if node.name == shape_node_name:
            shape_node = node
    if shape_node == None:
        print('[ERROR in modify_data_shape] node %s not found' %
            shape_node_name)
        return
    shape_node.attr['value'].tensor.tensor_shape.dim[0].size = len(new_shape)
    shape_ndarray = np.asarray(new_shape, dtype='int32')
    shape_buffer = shape_ndarray.tobytes()
    #print('[DEBUG] shape buffer: ', str(shape_buffer))
    shape_node.attr['value'].tensor.tensor_content = shape_buffer

def modify_pooling_config(graph_def, node_name,
                        ksize_list = [1,1,1,1],
                        strides_list = [1,1,1,1]):
    node_list = graph_def.node
    target_node = None
    for node in node_list:
        if node.name == node_name:
            target_node = node
    if target_node == None:
        print('[ERROR in modify_pooing_config] node %s not found' %
            node_name)
        return
    target_node.attr['ksize'].list.i[:] = ksize_list
    target_node.attr['strides'].list.i[:] = strides_list

def modify_test_graph(graph_def, test_op, repeat_number):
    global BASIC_GRAPH_TEST_OP_NAME

    node_list = graph_def.node
    for node in node_list:
        if node.name == BASIC_GRAPH_TEST_OP_NAME:
            node.op = test_op
            op_chain = create_op_chain(graph_def, node, repeat_number)
    return op_chain



if __name__ == '__main__':
    graph_def = load_protobuf_from_file('basic_graphs/conv2d.pbtxt')
    print("Loaded")
    #modify_data_shape(graph_def, 'data_0/shape', [1024,1024])
    #modify_data_shape(graph_def, 'data_1/shape', [1024,512])
    print('Data shape modified')
    modify_conv2d_config(graph_def, 'test_op', strides_list = [1,2,2,1])
    #modify_test_graph(graph_def, 'MatMul', 1000)
    modify_test_graph(graph_def, 'Conv2D', 10)
    save_protobuf_to_file(graph_def, 'test_graph.pbtxt')

    config=tf.ConfigProto()
    tf.reset_default_graph()
    tf.import_graph_def(graph_def)
    with tf.train.MonitoredTrainingSession(
            config=config) as sess:
        sess.graph.as_default()
        final_tensor = sess.graph.get_tensor_by_name('import/test_op_9:0')
        sess.run(final_tensor)