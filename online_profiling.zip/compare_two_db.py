import json

db_name_src = './jf_graphs_result/vgg16_db.json'
db_name_dst = './AMD_result/vgg16_db.json'
with open(db_name_src, 'r') as fd_in:
    db_src = json.load(fd_in)
with open(db_name_dst, 'r') as fd_in:
    db_dst = json.load(fd_in)

common_result_list = [] # key, op, db_src, db_dst
src_only_result_list = []
dst_only_result_list = []
for key in db_src:
    op = key.split('%')[0]
    if key in db_dst:
        common_result_list.append([key.replace(',','_'), op, db_src[key]['avg'], db_dst[key]['avg']])
    else:
        src_only_result_list.append([key.replace(',','_'), op, db_src[key]['avg']])
for key in db_dst:
    op = key.split('%')[0]
    if key not in db_src:
        dst_only_result_list.append([key.replace(',','_'), op, db_dst[key]['avg']])

with open('db_compare_result.csv','w') as fd_out:
    print('Key in both two DB:', file=fd_out)
    print('key, op, db_src, db_dst', file=fd_out)
    for record in common_result_list:
        record = str(record)[1:-1]
        print(record, file=fd_out)
    
    print('Key only in src DB:', file=fd_out)
    print('key, op, db_src', file=fd_out)
    for record in src_only_result_list:
        record = str(record)[1:-1]
        print(record, file=fd_out)
    
    print('Key only in dst DB:', file=fd_out)
    print('key, op, db_dst', file=fd_out)
    for record in dst_only_result_list:
        record = str(record)[1:-1]
        print(record, file=fd_out)

print('Done')
        

