import math
import os
import json

GPU_JOB_STREAM_NAME = '/job:localhost/replica:0/task:0/device:GPU:0 Compute'
GPU_STREAM_NAME = '/device:GPU:0/stream:all Compute'
CPU_STREAM_NAME = '/job:localhost/replica:0/task:0/device:CPU:0 Compute'
STREAM_CREATE_NAME = 'process_name'
DIR = './profiling_timelines/Add/'

# Parse one step timeline
def parse_single_prof_timeline(filename):
    global GPU_JOB_STREAM_NAME
    global GPU_STREAM_NAME
    global CPU_STREAM_NAME
    global STREAM_CREATE_NAME

    # The pid of 3 different streams
    gpu_pid = -1
    cpu_pid = -1
    gpu_job_pid = -1
    # Load the data, find pid of different streams
    with open(filename,'r') as fd:
        trace_list = json.load(fd)['traceEvents']
    for event in trace_list:
        if gpu_pid >= 0 and cpu_pid >= 0:
            break
        if event['name'] != STREAM_CREATE_NAME:
            continue 
        if event['args']['name'] == CPU_STREAM_NAME:
            cpu_pid = event['pid']
        if event['args']['name'] == GPU_STREAM_NAME:
            gpu_pid = event['pid']
        if event['args']['name'] == GPU_JOB_STREAM_NAME:
            gpu_job_pid = event['pid']

    # Record for each test op.
    # Each record contains [cpu_time, gpu_job_time, gpu stream time]
    start_time = -1
    end_time = 0
    for event in trace_list:
        if event['name'] == 'unknown':
            continue
        if 'args' not in event:
            continue
        if 'name' not in event['args']:
            continue
        if 'test_op' not in event['args']['name']:
            continue
      
        # Record start time
        if start_time == -1:
            start_time = event['ts']
        else:
            if start_time > event['ts']:
                start_time = event['ts']
        # Record end time
        if end_time < event['ts'] + event['dur']:
            end_time = event['ts'] + event['dur']

    return (end_time - start_time)/1000

# Parse all steps timeline of an op
def parse_all_timeline(timeline_dir, warmup_steps=5):
    filetree = os.walk(timeline_dir)
    avg = 0
    mid = 0
    std_err = 0
    records = []
    total = 0
    for path, dirList, fileList in filetree:
        for fileName in fileList:
            fileFullName = os.path.join(path,fileName)
            print('[DEBUG] Check file: ', fileFullName)
            if fileFullName[-4:] != 'json':
                continue
            step_id = int(fileName.replace('timeline-','').replace('.json',''))
            if step_id < warmup_steps:
                continue
            print('[DEBUG] open file: ', fileFullName)
            timeline_record = parse_single_prof_timeline(fileFullName)
            records.append(timeline_record)
            total += timeline_record
    avg = total / len(records)
    mid = get_medium(records)
    mean_square_err = 0.0
    for record in records:
        mean_square_err += (record - avg) * (record - avg)
    mean_square_err /= len(records)
    mean_std_err = math.sqrt(mean_square_err)

    print('avg: %f' % avg)
    print('mid: %f' % mid)
    print('std_err: %f' % mean_std_err)

def get_medium(input_list):
    sorted_list = sorted(input_list)
    list_len = len(sorted_list)
    return sorted_list[list_len // 2]

def get_min(input_list):
    sorted_list = sorted(input_list)
    return sorted_list[0]

if __name__ == '__main__':
    parse_all_timeline(DIR)