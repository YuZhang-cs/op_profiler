import math
NORMAL_RESULT_FILE = 'C:/Users/hhm00/Documents/superscalar-interface/SuperScaler/plan_gen/tests/data/jf_graphs_result/deepspeech/profiling.csv'
SMALL_RESULT_FILE = 'C:/Users/hhm00/Documents/superscalar-interface/SuperScaler/plan_gen/tests/data/jf_graphs_result/deepspeech/simple.csv'
OUTPUT_FILE = 'C:/Users/hhm00/Documents/superscalar-interface/SuperScaler/plan_gen/tests/data/jf_graphs_result/deepspeech/merged.csv'
result = []

# small result contains all ops
with open(SMALL_RESULT_FILE, 'r') as fdin:
    lines = fdin.readlines()
for line in lines:
    line_list = line.replace('\n','').split(',')
    if len(line_list) != 3:
        continue
    name = line_list[0]
    try:
        avg = float(line_list[1])
        std_err = float(line_list[2])
    except:
        continue
    result.append([name, avg, std_err])

cnt = 0
normal_cnt = 0
with open(NORMAL_RESULT_FILE, 'r') as fdin:
    lines = fdin.readlines()
for line in lines:
    line_list = line.replace('\n','').split(',')
    if len(line_list) != 3:
        continue
    try:
        avg = float(line_list[1])
        std_err = float(line_list[2])
    except:
        continue
    name = line_list[0]
    avg = float(line_list[1])
    std_err = float(line_list[2])
    while name != result[cnt][0]:
        print('[WARNING] Node name not same: %s' % name)
        cnt+=1
    if math.isclose(result[cnt][1], 0.0):
        # this node in small op result
        result[cnt] = [name, avg, std_err]
        normal_cnt += 1
    cnt += 1


with open(OUTPUT_FILE, 'w') as fdout:
    for record in result:
        fdout.write('%s,%f,%f\n'%(record[0], record[1], record[2]))
small_cnt = len(result) - normal_cnt
print('Done, total small op: %d' % small_cnt)