#! /bin/sh
rm dump/*
TF_DUMP_GRAPH_PREFIX=./dump TF_CPP_MIN_VLOG_LEVEL=4 python3 generate_basic_graph.py
