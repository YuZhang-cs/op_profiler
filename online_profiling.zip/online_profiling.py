import tensorflow as tf
import modify_test_graph as mod
import gen_var_related_graph as var_related
import profiling
import copy
import traceback
from online_prof_define import *
import special_op_prof as special_op
FLAGS = tf.app.flags.FLAGS


node_id_dict = {}

'''
Add random float input node pair into graph. 
Including shape and init node.
These nodes are copied from data_0 node pair.
'''
def add_random_input_group(graph_def, 
                    new_shape_name,
                    new_init_name,
                    new_cast_name,
                    raw_shape_name='data_0/shape',
                    raw_init_name='data_0/RandomUniform',
                    raw_cast_name='data_0/Cast',
                    dtype=tf.float32
                    ):
    raw_shape_node = mod.get_node_by_name(
                            graph_def, raw_shape_name)
    raw_init_node = mod.get_node_by_name(
                            graph_def, raw_init_name)
    raw_cast_node = mod.get_node_by_name(
                            graph_def, raw_cast_name)                     
    if  raw_shape_node == None or raw_init_node == None or raw_cast_node == None:
        print('Cannot find raw shape or init node in graph!')
        return None
    
    new_shape_node = copy.deepcopy(raw_shape_node)
    new_shape_node.name = new_shape_name

    new_init_node = copy.deepcopy(raw_init_node)
    new_init_node.name = new_init_name
    new_init_node.input[0] = new_shape_name

    new_cast_node = copy.deepcopy(raw_cast_node)
    new_cast_node.name = new_cast_name
    new_cast_node.input[0] = new_init_name
    new_cast_node.attr['DstT'].type = mod.dtype_dict[dtype]

    graph_def.node.append(new_shape_node)
    graph_def.node.append(new_init_node)
    graph_def.node.append(new_cast_node)

    return new_cast_node

def reset_colocate(target_node, colocate_node_name='test_op'):
    '''
    attr {
        key: "_class"
            value {
                list {
                    s: "loc:@global_step"
            }
        }
    }
    '''

    if not hasattr(target_node, 'attr'):
        return
    if '_class' not in target_node.attr:
        return
    target_node.attr['_class'].list.s[0] = \
                        bytes('loc:@' + colocate_node_name, 'ascii')

# Generate input nodes for non-var-related nodes
# Return a list of input nodes
def gen_input_nodes(graph_def, input_desc_list):
    input_node_list = []
    for i in range(len(input_desc_list)):
        input_desc = input_desc_list[i]
        
        # If no info for input, means dependency input.
        # All dependency inputs are renamed to START_NODE
        if input_desc == None:
            input_node_list.append(None)
            continue
        
        # For shape input, generate const int32 node
        if input_desc.is_shape_input:
            shape_node = mod.get_node_by_name(graph_def, 'data_0/shape')
            input_node = copy.deepcopy(shape_node)
            input_node.name = 'data_%d/const' % (i)
            input_node_list.append(input_node)
            graph_def.node.append(input_node)
            mod.modify_data_shape(graph_def, 
                            input_node.name, input_desc.shape)
            continue
            

        # For const input, just copy the origin node into test graph.
        # Reset the colocate info.
        if input_desc.is_const == True:
            input_node = copy.deepcopy(input_desc.origin_node)
            input_node.name = 'data_%d/Const' % (i)
            reset_colocate(input_node)
            input_node_list.append(input_node)
            graph_def.node.append(input_node)
            continue

        # For content independent float input
        # Use previous code to generate inputs.
        input_type = input_desc.type

        shape_node_name = 'data_%d/shape' % (i)
        init_node_name = 'data_%d/RandomUniform' % (i)
        cast_node_name = 'data_%d/Cast' % (i)
        init_node = mod.get_node_by_name(graph_def, 
                                init_node_name)
        shape_node = mod.get_node_by_name(graph_def, shape_node_name)
        cast_node = mod.get_node_by_name(graph_def, cast_node_name)
        if cast_node != None and shape_node == None:
            print('One of shape node in basic graph is missing.')
            return None
        elif cast_node != None and shape_node != None:
            # Already exists this input pair.
            cast_node.attr['DstT'].type = mod.dtype_dict[input_type]
            input_node_list.append(cast_node)
        else:
            # Create shape and init node.
            cast_node = add_random_input_group(graph_def, 
                            shape_node_name, init_node_name,cast_node_name,
                            dtype = input_type)
            if cast_node == None:
                print('Create input node fail!')
                return None
            input_node_list.append(cast_node)
        # Modify shape node
        mod.modify_data_shape(graph_def, shape_node_name, 
                        input_desc.shape)
        
        
        # TODO: content independent int input
        
    return input_node_list
    
'''
Generate the profiling graph for a given test node.
dtype: the type of output tensor
'''
def gen_profiling_graph(basic_graph_filename, test_node,
                    input_desc_list = [], test_chain_len=FLAGS.test_chain_len,
                    dtype = tf.float32):
    test_node = copy.deepcopy(test_node)
    graph_def = mod.load_protobuf_from_file(basic_graph_filename)

    # Reset colocate for test_node
    reset_colocate(test_node)

    # Modify graph to generate input nodes
    # Each input contain a shape node and an init node.
    # Shape node: Const node to define input shape. E.g. 'data_0/shape'
    # Init node: Random uniform to generate input data.
    input_list = test_node.input

    # First step, generate input nodes for each input (both data and depend)
    input_node_list = gen_input_nodes(graph_def, input_desc_list)
    if input_node_list == None:
        return None

    # Second step, modify shape node and the name of init node 
    # For data input, modify shape and name
    # For control dependency, just skip, since all control dependency 
    # has been renamed to '^data_0/shape'
    for input_node_cnt in range(len(input_list)):
        # if control dependency, skip
        if input_node_list[input_node_cnt] == None:
            continue
        input_name = input_node_list[input_node_cnt].name
        if '^' in input_name:
            continue

        # Rename the input part in test node define 
        # according to input_node_list
        test_node.input[input_node_cnt] = input_name

    # Insert test node into original graph
    debug_save_graph_filename = 'test_graph.pbtxt'
    test_node.name = 'test_op'
    graph_def.node.append(test_node)
    op_chain = mod.create_op_chain(graph_def, test_node, test_chain_len, dtype=dtype)
    if FLAGS.save_op_test_graph == 1:
        mod.save_protobuf_to_file(graph_def, debug_save_graph_filename)

    return graph_def, op_chain

def gen_profiling_graph_var_related(node, input_desc_list,
                test_chain_len=FLAGS.test_chain_len):
    if 'Variable' in node.op:
        endpoint_tensor = var_related.gen_graph_Variable(node, 
                        chain_len=test_chain_len)
        return endpoint_tensor
    if node.op == 'Assign':
        endpoint_tensor = var_related.gen_graph_Assign(node, 
                        input_desc_list, chain_len=test_chain_len)
        return endpoint_tensor
    return None

def check_var_related(node, input_desc_list):
    if 'Variable' in node.op:
        return True
    if node.op == 'Assign':
        return True
    '''
    for input_desc in input_desc_list:
        input_node = input_desc.origin_node
        if 'Variable' in input_node.op:
            return True
    '''
    return False

'''
Do profiling of one node.
Extract input shape from graph and sent to gen_profiling_graph.
'''
def node_profiling(target_graph_def, node, input_desc_list, auto_tune=False,
                node_size = 1024,
                step_result_filename = './step_result/tmp.csv',
                dtype = tf.float32):
    print('[DEBUG] profiling node:', node.name)
    if FLAGS.enable_timeline == 1:
        enable_timeline = True
    else:
        enable_timeline = False
    if FLAGS.timeline_path[-1] != '/':
        timeline_path = FLAGS.timeline_path + '/' + node.name
    else:
        timeline_path = FLAGS.timeline_path + node.name
    if(node_size < 1024):
        node_size = 1024
    max_chain_len = FLAGS.max_graph_mem_size // node_size
    min_chain_len = FLAGS.min_chain_len
    test_chain_len = FLAGS.test_chain_len
    if test_chain_len > max_chain_len:
        test_chain_len = max_chain_len
    if test_chain_len < min_chain_len:
        test_chain_len = min_chain_len
    last_chain_len = test_chain_len
    basic_graph_filename = FLAGS.basic_graph
    profiling_tune_cnt = 0
    catch_oom_flag = False
    while(profiling_tune_cnt <= FLAGS.max_tune_cnt):
        if check_var_related(node, input_desc_list):
            profiling_graph_def = None
            endpoint_tensor = gen_profiling_graph_var_related(
                        node, input_desc_list, test_chain_len=test_chain_len)
        else:
            profiling_graph_def, endpoint_tensor = gen_profiling_graph(
                        basic_graph_filename, node, input_desc_list,
                        test_chain_len=test_chain_len, dtype=dtype)
        if profiling_tune_cnt == FLAGS.max_tune_cnt:
            auto_tune = False
        try:
            # return in microsecond
            avg_op_time, mean_std_err = profiling.profiling(
                            graph_def = profiling_graph_def, 
                            warmingup_round=FLAGS.test_warmup_steps, 
                            test_round=FLAGS.test_run_steps, 
                            final_tensor_name=endpoint_tensor, 
                            output_filename='tmp.txt',
                            test_op_chain_len=test_chain_len,
                            auto_tune=auto_tune,
                            ideal_step_sec=FLAGS.ideal_step_sec,
                            step_time_range_ratio=FLAGS.step_time_range_ratio,
                            step_result_filename=step_result_filename,
                            enable_timeline=enable_timeline,
                            timeline_path=timeline_path)
        except tf.errors.ResourceExhaustedError as e:
            # If meet OOM first time, disable auto tune, use last chain len.
            if not catch_oom_flag:
                catch_oom_flag = True
                auto_tune = False
                test_chain_len = last_chain_len
                continue
            else:
                test_chain_len = last_chain_len // 2
                last_chain_len = test_chain_len
        except Exception as e:
            #input('[DEBUG] Catch unknown error!')
            raise e
        # calculate step_time in seconds, compare to settings
        step_time = avg_op_time * test_chain_len / 1000000
        if auto_tune and mean_std_err == -1:
            # Assume that step time is linear to test chain len
            new_test_chain_len = int(FLAGS.ideal_step_sec / step_time) \
                                * test_chain_len
            # Can only change 10x one time 
            if new_test_chain_len > test_chain_len * 10:
                new_test_chain_len = test_chain_len * 10
            if new_test_chain_len < test_chain_len / 10:
                new_test_chain_len = test_chain_len // 10
            if new_test_chain_len > max_chain_len:
                new_test_chain_len = max_chain_len
            if new_test_chain_len < min_chain_len:
                new_test_chain_len = min_chain_len
            last_chain_len = test_chain_len
            test_chain_len = new_test_chain_len
        else:
            break
        profiling_tune_cnt+=1
    #print('[DEBUG] Node profiling end, press any key to continue')
    #input()
    return avg_op_time, mean_std_err

'''
Internal nodes start with '_', rename them by removing '_'.
Also need to modify all input nodes.
'''
def rename_internal_nodes(graph_def):
    node_list = graph_def.node
    rename_list = {}
    for node in node_list:
        if node.name[0] == '_':
            new_name = node.name[1:]
            rename_list[node.name] = new_name
            node.name = new_name
        for i in range(len(node.input)):
            prefix = ''
            suffix = ''
            input_name = node.input[i]
            if input_name[0] == '^':
                prefix = '^'
                input_name = input_name[1:]
            if ':' in input_name:
                suffix = ':'+input_name.split(':')[1]
                input_name = input_name.split(':')[0]
            if input_name in rename_list:
                input_name = rename_list[input_name]
                input_name = prefix + input_name + suffix
                node.input[i] = input_name
    return

def get_node_size(graph, node_name):
    node_tensor_name = node_name + ':0'
    try:
        node_tensor = graph.get_tensor_by_name(node_tensor_name)
    except Exception as e:
        return 1024
    node_shape = node_tensor.get_shape().as_list()
    node_type = node_tensor.dtype
    node_size = 1
    for dim in node_shape:
        node_size *= dim
    if node_type == tf.half or node_type == tf.int32:
        node_size *= 2
    else:
        node_size *= 4
    return node_size

def graph_profiling(target_graph_def, result_filename = 'graph_profiling.csv',
                step_result_path = './step_result/',
                fail_log_filename = 'fail_log.txt'):
    if FLAGS.use_timeline_prof == 1 and FLAGS.enable_timeline == 0:
        print('[ERROR] Use timeline profiling with enable_timeline flag 0!')
        return None
    log_file = open(fail_log_filename,'w')
    rename_internal_nodes(target_graph_def)
    node_list = target_graph_def.node
    input_desc_list_allnode = []
    node_mem_size_list = []
    node_input_ok = []
    fail_node_cnt = 0
    node_dtype_list = []
    fd_out = open(result_filename, 'w')
    global node_id_dict

    # Get all nodes input tensors shapes
    tf.reset_default_graph()
    tf.import_graph_def(target_graph_def, name='')

    # Non session way to load
    # After processing, in node def all dependency input is '^START'
    # Input_desc_list will record None for dependency input, 
    # and InputDescriptor for data input.
    print('Start analyzing input of nodes...')
    with tf.Session() as sess:
        graph = sess.graph
        sess.graph.as_default()
        tf.initialize_all_variables().run()
        node_idx = 0
        total_nodes = len(node_list)
        for node in node_list:
            if node_idx % 10000 == 1:
                print('Analyzed %d / %d' % (node_idx-1, total_nodes))
            node_id_dict[node.name] = node_idx
            node_idx += 1
            try:
                node_size = get_node_size(graph, node.name)
            except Exception as e:
                node_size = 1024

            node_mem_size_list.append(node_size)
            output_dtype = tf.float32
            if node.op not in special_op.special_input_ops:
                input_node_ok_flag = True
                input_desc_list =[]
                input_id = -1
                try:
                    output_name = node.name + ':0'
                    try:
                        output_tensor = graph.get_tensor_by_name(output_name)
                        output_dtype = output_tensor.dtype
                    except:
                        print("[DEBUG]%s has no output" % output_name)
                    
                    for input_name in node.input:
                        #print('[DEBUG] Analyzing the input tensor: %s' % input_name)
                        input_id += 1
                        input_node_name = input_name
                        # Takes which output tensor from input op, ':' in name
                        input_tensor_id = 0
                        # Deal with special input name
                        if input_name[0] == '^':
                            node.input[input_id] = '^' + STARTPOINT_NODE_NAME
                            input_desc_list.append(None)
                            input_node_name = input_name[1:]
                            continue
                        elif ':' not in input_name:
                            input_tensor_name = input_name + ':0'
                        else:
                            input_tensor_name = input_name
                            input_node_name = input_name.split(':')[0]
                            input_tensor_id = int(input_name.split(':')[1])
                        try:
                            input_tensor = graph.get_tensor_by_name(input_tensor_name)
                        except:
                            print('cannot find tensor:', input_tensor_name)
                            input_node_ok_flag = False
                            break
                        #input_shape = input_tensor.get_shape().as_list()
                        input_node = mod.get_node_by_name(target_graph_def, input_node_name,
                                        node_id_dict=node_id_dict)
                        if 'Shape' in input_node.op:
                            # If the input op is a shape op
                            # Find the original op
                            # Gen input desc with is_shape_input flag
                            print('[DEBUG] Dealing with shape input')

                            real_input_name = input_node.input[input_tensor_id]
                            if ':' not in real_input_name:
                                input_tensor_name = real_input_name + ':0'
                            input_node = mod.get_node_by_name(target_graph_def, real_input_name,
                                            node_id_dict=node_id_dict)
                            input_tensor = graph.get_tensor_by_name(input_tensor_name)
                            input_desc = InputDescriptor(input_node, 
                                            input_tensor, is_shape_input=True)
                        else:
                            input_desc = InputDescriptor(input_node, input_tensor)
                        input_desc_list.append(input_desc)
                        # [DEBUG]
                        '''
                        if 'Variable' in input_node.op:
                            print('[DEBUG]Shape of var', input_node.name)
                            print(input_tensor.get_shape().as_list())
                            print('This node shape:')
                            this_tensor = graph.get_tensor_by_name(node.name + ':0')
                            print(this_tensor.get_shape().as_list())
                            print('[DEBUG]-----')
                        '''  
                except:
                    print("Fail in parsing input of node " + node.name)
                    input_node_ok_flag = False
                    traceback.print_exc()
            else:
                try:
                    special_input_func = special_op.special_input_ops[node.op]
                    input_node_ok_flag, input_desc_list = \
                            special_input_func(graph, target_graph_def, node, node_id_dict)
                except:
                    print("Fail in parsing input of node " + node.name)
                    input_node_ok_flag = False
                    traceback.print_exc()
            node_dtype_list.append(output_dtype)
            node_input_ok.append(input_node_ok_flag)
            #while(len(input_shape_list)<4):
            #    input_shape_list = [1] + input_shape_list
            input_desc_list_allnode.append(input_desc_list)

    print('Input analyzing finished.')
    print('Start profiling...')
    input_fail_cnt = 0
    skip_flag = True
    for i in range(len(node_list)):
        node = node_list[i]
        # [DEBUG] Remove after debugging!
        #if node.op != 'FusedBatchNormGradV3':
        #    continue
        #if skip_flag:
        #    continue

        if 'horovod' in node.op.lower():
            print('[SKIP] Skip a horovod node')
            avg_time = 0.0
            mean_std_err = 0
        elif 'recv' in node.op.lower() or 'send' in node.op.lower():
            print('[SKIP] Skip a send/recv node')
            #log_file.write('[NEW_FAIL]Node %s profiling failed!\n' % node.name)
            #fail_node_cnt += 1
            #foo = input('Press any key...')
            avg_time = 0.0
            mean_std_err = 0
        elif not node_input_ok[i]:
            print('Node %s input parsing failed!' % node.name)
            log_file.write('[NEW_FAIL]Node %s profiling failed!\n' % node.name)
            log_file.write('Fail in input shape parsing.\n')
            fail_node_cnt += 1
            input_fail_cnt += 1
            continue
        elif node.op == 'NoOp':
            avg_time = 5.0
            mean_std_err = 0
            print('[SKIP] Skip a NoOp node')
        #if node.op == 'Const' or node.op == 'VariableV2' or node.op == 'Identity':
        #    avg_time = 10.0
        #    mean_std_err = 0
        #    print('[SKIP] Skip a const/var node')
        elif node.op == 'ApplyGradientDescent':
            avg_time = 10.0
            mean_std_err = 0
            print('[SKIP] Skip identity/applyGrad node')
        else:
            try:
                if FLAGS.save_op_step_result != 1:
                    step_result_filename = None
                else:
                    step_result_filename = step_result_path + '/' + node.name.replace('/','#') + '.csv'

                avg_time, mean_std_err = node_profiling(target_graph_def, 
                            node, input_desc_list_allnode[i],
                            auto_tune=FLAGS.chain_len_auto_tune==1,
                            node_size=node_mem_size_list[i],
                            step_result_filename=step_result_filename,
                            dtype = node_dtype_list[i])
            except: 
                print('Node %s profiling failed!' % node.name)
                log_file.write('[NEW_FAIL]Node %s profiling failed!\n' % node.name)
                fail_node_cnt += 1
                traceback.print_exc()
                traceback.print_exc(file=log_file)
                continue
        
        #avg_time, std_err = node_profiling(target_graph_def, 
        #                node, input_shape_list_allnode[i])
        #if std_err > avg_time * 0.02:
        #    print('Node %s profiling error is big. avg: %f, std_err: %f' %
        #                    (node.name, avg_time, std_err))
        fd_out.write('%s,%f,%f\n' % ((node.name, avg_time, mean_std_err)))
    
    fd_out.write('overall result:\n')
    fd_out.write('total node, %d\n' % len(node_list))
    fd_out.write('profile node, %d\n' % (len(node_list) - fail_node_cnt))
    fd_out.write('fail node, %d\n' % fail_node_cnt)
    fd_out.write('coverage, %f\n' % (1 - fail_node_cnt / len(node_list)))
    fd_out.write('input fail cnt, %d\n' % (input_fail_cnt))

    print('total node, %d\n' % len(node_list))
    print('profile node, %d\n' % (len(node_list) - fail_node_cnt))
    print('fail node, %d\n' % fail_node_cnt)
    print('coverage, %f\n' % (1 - fail_node_cnt / len(node_list)))
    print('input fail cnt, %d\n' % (input_fail_cnt))
        
    log_file.close()

    return [len(node_list) - fail_node_cnt,     # Pass
            fail_node_cnt,                      # Fail
            len(node_list),                     # Total
            1 - fail_node_cnt / len(node_list)] # Coverage %

def reset_all_node_to_gpu(graph_def):
    node_list = graph_def.node
    for node in node_list:
        if 'horovod' not in node.op.lower():
            node.device = 'gpu:0'

if __name__ == '__main__':
    dag_filename = FLAGS.test_graph
    graph_def = mod.load_protobuf_from_file(dag_filename)
    if FLAGS.all_on_gpu == 1:
        reset_all_node_to_gpu(graph_def)
    graph_profiling(graph_def,
        result_filename=FLAGS.single_model_result,
        step_result_path=FLAGS.step_result_path,
        fail_log_filename=FLAGS.single_model_fail_log)
